using System;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Query;
using Publix.Cloud.Sales360.Write.DAL;
using Publix.Cloud.Sales360.BL.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System.Collections.Generic;
using Publix.Cloud.Sales360.Common.Cosmos;
using Microsoft.Azure.Cosmos;

namespace Publix.Cloud.Sales360.API.BL.Test
{
    public class SalesTransactionSearchByFilterReceiptIdsHandlerTest
	{
		[Fact]
		public void Test_SalesTransactionSearchByFilterReceiptIdsHandler_With_ValidReceiptIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterReceiptIdsHandler>>();

			var request = new SalesTransactionSearchByReceiptIdQuery()
			{
				ReceiptIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterReceiptIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.NotEmpty(actualResponse.Data);
			Assert.Equal(actualResponse.Data.Count, request.ReceiptIds.Length);
		}


		[Fact]
		public void Test_SalesTransactionSearchByFilterReceiptIdsHandler_With_InvalidReceiptIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterReceiptIdsHandler>>();

			var request = new SalesTransactionSearchByReceiptIdQuery()
			{
				ReceiptIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(null))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterReceiptIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Null(actualResponse.Data);
			Assert.Equal("421", actualResponse.StatusCode);

		}

		[Fact]
		public void Test_SalesTransactionSearchByFilterReceiptIdsHandler_With_NullOrEmptyInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterReceiptIdsHandler>>();

			var request = new SalesTransactionSearchByReceiptIdQuery()
			{
				ReceiptIds = new string[0]
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterReceiptIdsHandler(mockRepo.Object, mockLogger.Object);
			//Act
			Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(request, default));
		}

		[Fact]
		public void Test_SalesTransactionSearchByFilterReceiptIdsHandler_With_NullInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterReceiptIdsHandler>>();

			var request = new SalesTransactionSearchByReceiptIdQuery()
			{
				ReceiptIds = null
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterReceiptIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(request, default));



		}


		[Fact]
		public void Test_SalesTransactionSearchByFilterReceiptIdsHandlerr_With_CosmosException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterReceiptIdsHandler>>();

			var request = new SalesTransactionSearchByReceiptIdQuery()
			{
				ReceiptIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Throws(new CosmosException("Error", System.Net.HttpStatusCode.TooManyRequests, 0, "", 0))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterReceiptIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act and Assert
			Assert.ThrowsAsync<CosmosException>(() => handler.Handle(request, default));

		}

		[Fact]
		public void Test_SalesTransactionSearchByReceiptIdsHandler_With_GeneralException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterReceiptIdsHandler>>();

			var request = new SalesTransactionSearchByReceiptIdQuery()
			{
				ReceiptIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Throws(new Exception("Error"))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterReceiptIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act and Assert
			Assert.ThrowsAsync<Exception>(() => handler.Handle(request, default));

		}
	}
}

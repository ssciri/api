using System;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Query;
using Publix.Cloud.Sales360.Write.DAL;
using Publix.Cloud.Sales360.BL.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System.Collections.Generic;
using Publix.Cloud.Sales360.Common.Cosmos;

namespace Publix.Cloud.Sales360.API.BL.Test
{
    public class SalesTransactionSearchByTransactionIdsHandlerTest
    {
		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_ValidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByTransactionIdsHandler>>();

			var request = new SalesTransactionSearch()
			{
				SearchRequestId = "1",
				TransactionIds = new string[] { "1", "2", "3" }
			};
			
			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1", ReceiptDetail = new ReceiptDetail(){ReceiptId = "1" } },
				new SalesTransaction() { TransactionId = "2", ReceiptDetail = new ReceiptDetail(){ReceiptId = "2" } },
				new SalesTransaction() { TransactionId = "3", ReceiptDetail = new ReceiptDetail(){ReceiptId = "3" } }
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByTransactionIdsHandler(mockRepo.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId,actualResponse.SearchRequestId);
			Assert.NotEmpty(actualResponse.Transactions);
			Assert.Equal(actualResponse.Transactions.Count, request.TransactionIds.Length);
			//Assert.Equal(actualResponse.Transactions, expectedTransactionsInfo);
		}

		
		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_ValidInvalidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByTransactionIdsHandler>>();

			var request = new SalesTransactionSearch()
			{
				SearchRequestId = "1",
				TransactionIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>() ;
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByTransactionIdsHandler(mockRepo.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByReceiptIds(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
					
		}

		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_ValidNullOrEmptyInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByTransactionIdsHandler>>();

			var request = new SalesTransactionSearch()
			{
				SearchRequestId = "1",
				TransactionIds = new string[0]
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByTransactionIdsHandler(mockRepo.Object);
			//Act
			Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(request, default));
		}

		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_ValidNullInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByTransactionIdsHandler>>();

			var request = new SalesTransactionSearch()
			{
				SearchRequestId = "1",
				TransactionIds = null
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByTransactionIdsHandler(mockRepo.Object);

			// Act
			Assert.ThrowsAsync<ArgumentNullException>( () => handler.Handle(request, default));

			
			
		}
	}
}

﻿using Microsoft.Extensions.Logging;
using Moq;
using Publix.Cloud.Sales360.BL.Handlers.Query;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Publix.Cloud.Sales360.BL.Test.Handlers
{
    public class SalesTransactionSearchByCustomerSelfIdentificationsHandlerTest
    {
		[Fact]
		public void Test_SalesTransactionSearchByCustomerSelfIdentificationsr_With_ValidData()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByCustomerSelfIdentificationsHandler>>();

			var request = new SalesTransactionSearchByCustomerSelfIdentificationsQuery()
			{	
				CustomerId = new string[] { "8635956082", "8637013432" , "8637013431" },
				CustomerIdType = 1,
				CustomerIdCaptureReasonCodes = new int[] { 1 },
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByCustomerIdentifications(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByCustomerSelfIdentificationsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByCustomerIdentifications(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.NotEmpty(actualResponse.Data);
			Assert.Equal(actualResponse.Data.Count, request.CustomerId.Length);
		}

		[Fact]
		public void Test_SalesTransactionSearchByCustomerSelfIdentificationsr_With_InValidData()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByCustomerSelfIdentificationsHandler>>();

			var request = new SalesTransactionSearchByCustomerSelfIdentificationsQuery()
			{
				CustomerId = new string[] { "8635956082", "8637013432", "8637013431" },
				CustomerIdType = 1,
				CustomerIdCaptureReasonCodes = new int[] { 1 },
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};


			// Arrange
			mockRepo.Setup(str => str.GetTransactionByCustomerIdentifications(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(null))
				.Verifiable();

			var handler = new SalesTransactionSearchByCustomerSelfIdentificationsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByCustomerIdentifications(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Null(actualResponse.Data);
			Assert.Equal("421", actualResponse.StatusCode);
		}
	}
}

using System;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Query;
using Publix.Cloud.Sales360.Write.DAL;
using Publix.Cloud.Sales360.BL.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System.Collections.Generic;
using Microsoft.Azure.Cosmos;
using System.Net;
using Publix.Cloud.Sales360.Common.Cosmos;

namespace Publix.Cloud.Sales360.API.BL.Test
{
    public class SalesTransactionSearchByFilterTransactionIdsHandlerTest
    {
		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_ValidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterTransactionIdsHandler>>();

			var request = new SalesTransactionSearchByTransactionIdQuery()
			{
				TransactionIds = new string[] { "1", "2", "3" }
			};
			
			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterTransactionIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.NotEmpty(actualResponse.Data);
			Assert.Equal(actualResponse.Data.Count, request.TransactionIds.Length);
			//Assert.Equal(actualResponse.Transactions, expectedTransactionsInfo);
		}

		
		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_InvalidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterTransactionIdsHandler>>();

			var request = new SalesTransactionSearchByTransactionIdQuery()
			{
				TransactionIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>() ;
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(null))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterTransactionIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockRepo.Verify(x => x.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Null(actualResponse.Data);
			Assert.Equal("421", actualResponse.StatusCode);

		}

		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_NullOrEmptyInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterTransactionIdsHandler>>();

			var request = new SalesTransactionSearchByTransactionIdQuery()
			{
				TransactionIds = new string[0]
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterTransactionIdsHandler(mockRepo.Object, mockLogger.Object);
			//Act
			Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(request, default));
		}

		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_NullInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterTransactionIdsHandler>>();

			var request = new SalesTransactionSearchByTransactionIdQuery()
			{
				TransactionIds = null
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterTransactionIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act
			Assert.ThrowsAsync<ArgumentNullException>( () => handler.Handle(request, default));

			
			
		}


		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_CosmosException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterTransactionIdsHandler>>();

			var request = new SalesTransactionSearchByTransactionIdQuery()
			{
				TransactionIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Throws(new CosmosException("Error", System.Net.HttpStatusCode.TooManyRequests,0,"",0))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterTransactionIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act and Assert
			Assert.ThrowsAsync<CosmosException>(() => handler.Handle(request, default));

		}

		[Fact]
		public void Test_SalesTransactionSearchByTransactionIdsHandler_With_GeneralException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByFilterTransactionIdsHandler>>();

			var request = new SalesTransactionSearchByTransactionIdQuery()
			{
				TransactionIds = new string[] { "1", "2", "3" }
			};

			var expectedTransactions = new List<SalesTransaction>();
			// Arrange
			mockRepo.Setup(str => str.GetTransactionByTransactionIds(It.IsAny<SearchParameters>()))
				.Throws(new Exception("Error"))
				.Verifiable();

			var handler = new SalesTransactionSearchByFilterTransactionIdsHandler(mockRepo.Object, mockLogger.Object);

			// Act and Assert
			Assert.ThrowsAsync<Exception>(() => handler.Handle(request, default));

		}
	}
}

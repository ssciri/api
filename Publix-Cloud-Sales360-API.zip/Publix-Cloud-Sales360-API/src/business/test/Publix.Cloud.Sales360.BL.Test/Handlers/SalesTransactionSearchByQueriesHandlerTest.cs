using System;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Query;
using Publix.Cloud.Sales360.Write.DAL;
using Publix.Cloud.Sales360.BL.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System.Collections.Generic;
using MediatR;
using Microsoft.Azure.Cosmos;

namespace Publix.Cloud.Sales360.API.BL.Test
{
	public class SalesTransactionSearchByQueriesHandlerTest
	{
		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_TransactionId_With_ValidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "TransactionId" },
				Data = new SearchData()
				{
					TransactionId = new string[] { "1", "2", "3" }
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};

			var expectedResponse = new SalesTransactionsQueryResponse()
			{
				Data = expectedTransactions
			};

			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default))
				.Returns(Task.FromResult<SalesTransactionsQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
			Assert.Null(actualResponse.TransactionsByPartialCardNoQuery);
			Assert.Null(actualResponse.TransactionsByPhoneNumberItemIdQuery);
			Assert.NotNull(actualResponse.TransactionsByTransactionIdQuery);
			Assert.Equal(actualResponse.TransactionsByTransactionIdQuery.Data.Count, request.Data.TransactionId.Length);
			//Assert.Equal(actualResponse.Transactions, expectedTransactionsInfo);
		}

		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_TransactionId_With_DateRange_ValidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "TransactionId" },
				Data = new SearchData()
				{
					TransactionId = new string[] { "1", "2", "3" },
					DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-10"), EndDate = DateTime.Parse("2021-03-10") }
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};

			var expectedResponse = new SalesTransactionsQueryResponse()
			{
				Data = expectedTransactions
			};

			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default))
				.Returns(Task.FromResult<SalesTransactionsQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
			Assert.Null(actualResponse.TransactionsByPartialCardNoQuery);
			Assert.Null(actualResponse.TransactionsByPhoneNumberItemIdQuery);
			Assert.NotNull(actualResponse.TransactionsByTransactionIdQuery);
			Assert.Equal(actualResponse.TransactionsByTransactionIdQuery.Data.Count, request.Data.TransactionId.Length);
			//Assert.Equal(actualResponse.Transactions, expectedTransactionsInfo);
		}


		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_TransactionId_With_InvalidTransactionIds()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "TransactionId" },
				Data = new SearchData()
				{
					TransactionId = new string[] { "1", "2" }
				}
			};

			var expectedResponse = new SalesTransactionsQueryResponse()
			{
				Data = new List<SalesTransaction>()
			};

			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default))
				.Returns(Task.FromResult<SalesTransactionsQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);

			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
			Assert.Null(actualResponse.TransactionsByPartialCardNoQuery);
			Assert.Null(actualResponse.TransactionsByPhoneNumberItemIdQuery);
			Assert.NotNull(actualResponse.TransactionsByTransactionIdQuery);
		}

		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_With_ValidData()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber" },
				Data = new SearchData() { ItemId = new string[] { "1", "2", "3" }, PhoneNumber = "1234" }
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};

			var expectedResponse = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};

			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				.Returns(Task.FromResult<PhoneNumberQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
			Assert.Null(actualResponse.TransactionsByPartialCardNoQuery);
			Assert.NotNull(actualResponse.TransactionsByPhoneNumberItemIdQuery);
			Assert.Null(actualResponse.TransactionsByTransactionIdQuery);
			Assert.Equal(actualResponse.TransactionsByPhoneNumberItemIdQuery.Data.Count, request.Data.ItemId.Length);

		}


		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_With_DateRange_ValidData()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber" },
				Data = new SearchData() { ItemId = new string[] { "1", "2", "3" }, PhoneNumber = "1234" ,
				DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-10"), EndDate = DateTime.Parse("2021-03-10") }
				}
			
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};

			var expectedResponse = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};

			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				.Returns(Task.FromResult<PhoneNumberQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
			Assert.Null(actualResponse.TransactionsByPartialCardNoQuery);
			Assert.NotNull(actualResponse.TransactionsByPhoneNumberItemIdQuery);
			Assert.Null(actualResponse.TransactionsByTransactionIdQuery);
			Assert.Equal(actualResponse.TransactionsByPhoneNumberItemIdQuery.Data.Count, request.Data.ItemId.Length);

		}


		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_And_TransactionId_With_ValidData()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber", "TransactionId" },
				Data = new SearchData() {
					ItemId = new string[] { "1", "2", "3" },
					PhoneNumber = "1234",
					TransactionId = new string[] { "1", "2", "3" },
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};


			var expectedResponse = new SalesTransactionsQueryResponse()
			{
				Data = expectedTransactions
			};

			var expectedResponse1 = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};


			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				.Returns(Task.FromResult<PhoneNumberQueryResponse>(expectedResponse1))
				.Verifiable();

			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default))
				.Returns(Task.FromResult<SalesTransactionsQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act
			var actualResponse = handler.Handle(request, default).Result;

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default), Times.Once());
			Assert.NotNull(actualResponse);
			Assert.Equal(request.SearchRequestId, actualResponse.SearchRequestId);
			Assert.Null(actualResponse.TransactionsByPartialCardNoQuery);
			Assert.NotNull(actualResponse.TransactionsByPhoneNumberItemIdQuery);
			Assert.NotNull(actualResponse.TransactionsByTransactionIdQuery);
			Assert.Equal(actualResponse.TransactionsByPhoneNumberItemIdQuery.Data.Count, request.Data.TransactionId.Length);

		}

		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_With_NullOrEmptyInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			// Arrange
			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[0],
				Data = new SearchData() { }
			};


			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			//Act
			Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(request, default));
		}

		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_With_NullInput()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			// Arrange

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = null,
				Data = null
			};


			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);

			// Act
			Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(request, default));
		}


		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_And_TransactionId_With_ValidData_FirstOneThrowsException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber", "TransactionId" },
				Data = new SearchData()
				{
					ItemId = new string[] { "1", "2", "3" },
					PhoneNumber = "1234",
					TransactionId = new string[] { "1", "2", "3" },
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};


			var expectedResponse = new SalesTransactionsQueryResponse()
			{
				Data = expectedTransactions
			};

			var expectedResponse1 = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};


			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				//.Returns(Task.FromResult<PhoneNumberAndItemIdInfo>(expectedResponse1))
				.ThrowsAsync(new CosmosException("Error", System.Net.HttpStatusCode.TooManyRequests, 0, "", 0))
				.Verifiable();

			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default))
				.Returns(Task.FromResult<SalesTransactionsQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act and Assert
			Assert.ThrowsAsync<CosmosException>(() => handler.Handle(request, default));

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default), Times.Once());

		}

		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_With_InvalidDateRange_ValidData_ThrowsException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber"},
				Data = new SearchData()
				{
					ItemId = new string[] { "1", "2", "3" },
					PhoneNumber = "1234",
					TransactionId = new string[] { "1", "2", "3" },
					DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-10") }
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};


			var expectedResponse = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};

			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				.Returns(Task.FromResult<PhoneNumberQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act and Assert
			var r = handler.Handle(request, default);

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());
		
		}


		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_With_NullDateRange_ValidData_ThrowsException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber" },
				Data = new SearchData()
				{
					ItemId = new string[] { "1", "2", "3" },
					PhoneNumber = "1234",
					TransactionId = new string[] { "1", "2", "3" },
					DateRange = null
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};


			var expectedResponse = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};

			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				.Returns(Task.FromResult<PhoneNumberQueryResponse>(expectedResponse))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act and Assert
			var r = handler.Handle(request, default);

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());

		}



		[Fact]
		public void Test_SalesTransactionSearchByQueriesHandlerTest_Filter_PhoneNoItemId_And_TransactionId_With_ValidData_LastOneThrowsException()
		{
			var mockRepo = new Mock<ITransactionReadOnlyRepository>();
			var mockLogger = new Mock<ILogger<SalesTransactionSearchByQueriesHandler>>();
			var mockMediator = new Mock<IMediator>();

			var request = new SalesTransactionSearchByQueries()
			{
				SearchRequestId = "1",
				Queries = new string[] { "Phonenumber", "TransactionId" },
				Data = new SearchData()
				{
					ItemId = new string[] { "1", "2", "3" },
					PhoneNumber = "1234",
					TransactionId = new string[] { "1", "2", "3" },
				}
			};

			var expectedTransactions = new List<SalesTransaction>() {
				new SalesTransaction(){ TransactionId = "1"},
				new SalesTransaction() { TransactionId = "2"},
				new SalesTransaction() { TransactionId = "3"}
			};

			var expectedTransactionsInfo = new List<SalesTransactionInfo>() {
				new SalesTransactionInfo(){ TransactionId = "1"},
				new SalesTransactionInfo() { TransactionId = "2"},
				new SalesTransactionInfo() { TransactionId = "3"}
			};


			var expectedResponse = new SalesTransactionsQueryResponse()
			{
				Data = expectedTransactions
			};

			var expectedResponse1 = new PhoneNumberQueryResponse()
			{
				Data = expectedTransactions
			};


			// Arrange
			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default))
				.Returns(Task.FromResult<PhoneNumberQueryResponse>(expectedResponse1))
				.Verifiable();

			mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default))
				.ThrowsAsync(new CosmosException("Error", System.Net.HttpStatusCode.TooManyRequests, 0, "", 0))
				.Verifiable();

			var handler = new SalesTransactionSearchByQueriesHandler(mockMediator.Object, mockLogger.Object, mockRepo.Object);
			// Act and Assert
			Assert.ThrowsAsync<CosmosException>(() => handler.Handle(request, default));

			// Assert
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByPhoneNumberQuery>(), default), Times.Once());
			mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByTransactionIdQuery>(), default), Times.Once());

		}
	}

}

﻿using MediatR;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.Write.DAL;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Threading;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.BL.Command
{
    public class CreateSalesTransactionHandler : IRequestHandler<CreateSalesTransaction, SalesTransactionResponse>
    {
        private ISales360WriteDAL repository;
        private ILogger<CreateSalesTransactionHandler> logger;



        public CreateSalesTransactionHandler(ISales360WriteDAL repository, ILogger<CreateSalesTransactionHandler> logger)
		{
            this.repository = repository;
            this.logger = logger;
        }

        /// <summary>
        /// Handles CreateSalesTransaction request and add salestransaction into cosmos db.
        /// </summary>
        /// <param name="request">CreateSalesTransaction</param>
        /// <param name="cancellationToken">CancellationToken</param>
        /// <returns></returns>
        public async Task<SalesTransactionResponse> Handle(CreateSalesTransaction request, CancellationToken cancellationToken)
        {
            logger.LogInformation("CreateSalesTransaction Handle init: {@request}", request);
            var result = new SalesTransactionResponse
            {
                IsSuccess = true
            };
            
            dynamic jsonData = convertToJson(request);
            await repository.CreateSalesTransaction(jsonData, jsonData.transactionId);
            logger.LogInformation("CreateSalesTransaction Handle completed");
            return result;
        }

        /// <summary>
        /// Convert to JSON and add Id field. 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
		private dynamic convertToJson(CreateSalesTransaction request)
		{
			var converter = new ExpandoObjectConverter();
			dynamic jsonData = null;
			jsonData = JsonConvert.DeserializeObject<ExpandoObject>(request.Data, converter);

            if (jsonData != null) {
                if (((IDictionary<string, object>)jsonData).ContainsKey("transactionId"))
			    {
                    jsonData.id = jsonData.transactionId;
                } 
            }
            return jsonData;
		}
	}
}

﻿using MediatR;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.API.Common;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Cloud.Sales360.Common.Logging;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.BL.Query
{
    public class SalesTransactionSearchByFilterPhoneNumberAndItemIdHandler : IRequestHandler<SalesTransactionSearchByPhoneNumberQuery, PhoneNumberQueryResponse>
    {
        private ITransactionReadOnlyRepository _transactionRepository;
        public ILogger<SalesTransactionSearchByFilterPhoneNumberAndItemIdHandler> _logger;

        public SalesTransactionSearchByFilterPhoneNumberAndItemIdHandler(ITransactionReadOnlyRepository repository, ILogger<SalesTransactionSearchByFilterPhoneNumberAndItemIdHandler> logger)
		{
            _transactionRepository = repository;
            _logger = logger;
        }

        
        public async Task<PhoneNumberQueryResponse> Handle(SalesTransactionSearchByPhoneNumberQuery request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request.PhoneNumber))
                throw new ArgumentNullException();

            Stopwatch stwatch = new Stopwatch();
            stwatch.Start();
            IList<SalesTransaction> transactions;
            transactions = await _transactionRepository.GetTransactionByPhoneAndItemIds( new SearchParameters { PhoneNumber = request.PhoneNumber,
                StartDate = request.StartDate,
                EndDate = request.EndDate,
                ItemId = request.ItemId});
            stwatch.Stop();            
            _logger.LogInformation(LoggingConstants.Template,
                                    "SalesTransactionSearchByFilterPhoneNumberAndItemIdHandler",
                                    request.SearchRequestId,
                                    LoggingConstants.OperationName.SearchSalesTransactionByPhoneNumberAndItemId,
                                    LoggingConstants.EventCode.SearchByPhoneNumberAndItemIdSucceeded,
                                    stwatch.ElapsedMilliseconds,
                                    transactions?.Count
                                    );
            if (transactions == null || transactions.Count == 0)
                return CreateDefaultResponse(request);
            return CreateResponse(request, transactions);
        }

		private PhoneNumberQueryResponse CreateDefaultResponse(SalesTransactionSearchByPhoneNumberQuery request)
		{
            var result = new PhoneNumberQueryResponse()
            {
                ErrorMessage = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND,
                StatusCode = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND_STATUS_CODE
            };
            return result;
        }

        private PhoneNumberQueryResponse CreateResponse(SalesTransactionSearchByPhoneNumberQuery request, IList<SalesTransaction> transactions)
        {
            var result = new PhoneNumberQueryResponse()
            {
                Data = transactions.ToList()                
            };
            return result;
            
        }
    }
}

﻿using MediatR;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.API.Common;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Cloud.Sales360.Common.Logging;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.BL.Query
{
    public class SalesTransactionSearchByFilterReceiptIdsHandler : IRequestHandler<SalesTransactionSearchByReceiptIdQuery, SalesTransactionsQueryResponse>
    {
        private ITransactionReadOnlyRepository _transactionRepository;
        public ILogger<SalesTransactionSearchByFilterReceiptIdsHandler> _logger;

        public SalesTransactionSearchByFilterReceiptIdsHandler(ITransactionReadOnlyRepository repository, ILogger<SalesTransactionSearchByFilterReceiptIdsHandler> logger)
        {
            _transactionRepository = repository;
            _logger = logger;
        }
 

        public async Task<SalesTransactionsQueryResponse> Handle(SalesTransactionSearchByReceiptIdQuery request, CancellationToken cancellationToken)
        {
            if (request.ReceiptIds == null || request.ReceiptIds.Count() == 0)
                throw new ArgumentNullException();

            Stopwatch stwatch = new Stopwatch();
            stwatch.Start();

            IList<SalesTransaction> transactions;
            transactions = await _transactionRepository.GetTransactionByReceiptIds(new SearchParameters { ReceiptIds = request.ReceiptIds });
            stwatch.Stop();


            _logger.LogInformation(LoggingConstants.Template,
                                    "SalesTransactionSearchByReceiptIdsHandler",
                                    request.ReceiptIds,
                                    LoggingConstants.OperationName.SearchSalesTransactionByTransactionIds,
                                    LoggingConstants.EventCode.SearchByTransactionIdsSucceeded,
                                    stwatch.ElapsedMilliseconds,
                                    transactions?.Count
                                    );
            if (transactions == null || transactions.Count == 0)
                return CreateDefaultResponse(request);
            return CreateResponse(request, transactions);
        }

        private SalesTransactionsQueryResponse CreateDefaultResponse(SalesTransactionSearchByReceiptIdQuery request)
        {
            var result = new SalesTransactionsQueryResponse()
            {
                ErrorMessage = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND,
                StatusCode = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND_STATUS_CODE
            };
            return result;
        }

        private SalesTransactionsQueryResponse CreateResponse(SalesTransactionSearchByReceiptIdQuery request, IList<SalesTransaction> transactions)
        {
            var result = new SalesTransactionsQueryResponse()
            {
                Data = transactions.ToList()
            };
            return result;
        }
    }
}
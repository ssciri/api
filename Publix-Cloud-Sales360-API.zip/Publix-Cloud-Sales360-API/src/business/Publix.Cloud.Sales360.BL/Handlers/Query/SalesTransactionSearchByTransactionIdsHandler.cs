﻿using MediatR;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.API.Common;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.BL.Query
{
    public class SalesTransactionSearchByTransactionIdsHandler : IRequestHandler<SalesTransactionSearch, SalesTransactionSearchResponse>
    {
        private ITransactionReadOnlyRepository _transactionRepository;

        public SalesTransactionSearchByTransactionIdsHandler(ITransactionReadOnlyRepository repository)
		{
            _transactionRepository = repository;
        }

        
        public async Task<SalesTransactionSearchResponse> Handle(SalesTransactionSearch request, CancellationToken cancellationToken)
        {
            if (request.TransactionIds == null || request.TransactionIds.Count() == 0)
                throw new ArgumentNullException();
            var transactions = await _transactionRepository.GetTransactionByReceiptIds(new SearchParameters { ReceiptIds = request.TransactionIds });
            if (transactions == null)
                return CreateDefaultResponse(request);

            return CreateResponse(request, transactions);
        }

		private SalesTransactionSearchResponse CreateDefaultResponse(SalesTransactionSearch request)
		{
            var result = new SalesTransactionSearchResponse
            {
                SearchRequestId = request.SearchRequestId,
                Transactions = new List<SalesTransactionInfo>()
            };

            foreach (var transactionId in request.TransactionIds)
            {
                result.Transactions.Add(new SalesTransactionInfo()
                {
                    TransactionId = transactionId,
                    ErrorMessage = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND,
                    StatusCode = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND_STATUS_CODE
                });
            }
            return result;
        }

        private SalesTransactionSearchResponse CreateResponse(SalesTransactionSearch request, IList<SalesTransaction> transactions)
        {
            var result = new SalesTransactionSearchResponse
            {
                SearchRequestId = request.SearchRequestId,
                Transactions = new List<SalesTransactionInfo>()
            };

            foreach (var transactionId in request.TransactionIds)
            {
                var data = transactions.FirstOrDefault(c => c.ReceiptDetail.ReceiptId == transactionId);
                var hasError = data == null;
                result.Transactions.Add(new SalesTransactionInfo()
                {
                    TransactionId = transactionId,
                    Data = data,
                    ErrorMessage = hasError ? Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND : string.Empty,
                    StatusCode = hasError ? Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND_STATUS_CODE : string.Empty
                });
            }
            return result;
        }
    }
}

﻿using MediatR;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.API.Common;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.BL.Query
{
    public class SalesTransactionSearchByQueriesHandler : IRequestHandler<SalesTransactionSearchByQueries, SalesTransactionSearchByQueriesResponse>
    {
        private ITransactionReadOnlyRepository _transactionRepository;
        private readonly IMediator _mediator;
        public ILogger<SalesTransactionSearchByQueriesHandler> _logger;


        public SalesTransactionSearchByQueriesHandler(IMediator mediator, ILogger<SalesTransactionSearchByQueriesHandler> logger, ITransactionReadOnlyRepository repository)
        {
            _transactionRepository = repository;
            _mediator = mediator;
            _logger = logger;
        }


        public async Task<SalesTransactionSearchByQueriesResponse> Handle(SalesTransactionSearchByQueries request, CancellationToken cancellationToken)
        {
            if (request.Queries == null || request.Queries.Length == 0)
                throw new ArgumentNullException();

            var searchResponse = new SalesTransactionSearchByQueriesResponse()
            { SearchRequestId = request.SearchRequestId };

            List<Task> tasks = new List<Task>();
            request.Queries.ToList().ForEach(c =>
            {
                var queryFilter = Enum.Parse(typeof(QueryName), c, true);
                if (queryFilter != null)
                {
                    switch (queryFilter)
                    {
                        case QueryName.TransactionId:
                            tasks.Add(SearchByTransactionsId(request, searchResponse));
                            break;
                        case QueryName.Phonenumber:
                            tasks.Add(SearchByPhoneNumberAndItemId(request, searchResponse));
                            break;
                        case QueryName.PartialCardNumber:
                            tasks.Add(SearchByPartialCard(request, searchResponse));
                            break;
                        case QueryName.ReceiptId:
                            tasks.Add(SearchByReceiptId(request, searchResponse));
                            break;
                        case QueryName.CustomerSelfIdentifications:
                            tasks.Add(SearchByCustomerSelfIdentifications(request, searchResponse));
                            break;
                    }
                }
            });

            await Task.WhenAll(tasks).ConfigureAwait(false);
            return searchResponse;
        }

        private async Task SearchByPhoneNumberAndItemId(SalesTransactionSearchByQueries request, SalesTransactionSearchByQueriesResponse searchResponse)
        {
            var searchByPhoneAndItem = new SalesTransactionSearchByPhoneNumberQuery()
            {
                SearchRequestId = request.SearchRequestId,
                PhoneNumber = request.Data.PhoneNumber,
                ItemId = request.Data.ItemId,
                StartDate = request.Data.DateRange?.StartDate,
                EndDate = request.Data.DateRange?.EndDate
            };
            searchResponse.TransactionsByPhoneNumberItemIdQuery = await _mediator.Send(searchByPhoneAndItem); ;
        }

        //TransactionsByPartialCardNoFilter

        private async Task SearchByTransactionsId(SalesTransactionSearchByQueries request, SalesTransactionSearchByQueriesResponse searchResponse)
        {
            var searchByTransactionId = new SalesTransactionSearchByTransactionIdQuery()
            {
                SearchRequestId = request.SearchRequestId,
                TransactionIds = request.Data.TransactionId
            };
            searchResponse.TransactionsByTransactionIdQuery = await _mediator.Send(searchByTransactionId);

        }

        private async Task SearchByPartialCard(SalesTransactionSearchByQueries request, SalesTransactionSearchByQueriesResponse searchResponse)
        {
            var searchByPartialCard = new SalesTransactionSearchByPartialCardNumberQuery()
            {
                SearchRequestId = request.SearchRequestId,
                ItemId = request.Data.ItemId,
                StoreId = request.Data.StoreId,
                FirstSixCardNo = request.Data.FirstSixCardNo,
                LastFourCardNo = request.Data.LastFourCardNo,
                StartDate = request.Data.DateRange?.StartDate,
                EndDate = request.Data.DateRange?.EndDate
            };
            searchResponse.TransactionsByPartialCardNoQuery = await _mediator.Send(searchByPartialCard);

        }

        private async Task SearchByReceiptId(SalesTransactionSearchByQueries request, SalesTransactionSearchByQueriesResponse searchResponse)
        {
            var searchByReceiptId = new SalesTransactionSearchByReceiptIdQuery()
            {
                ReceiptIds = request.Data.ReceiptId
            };
            searchResponse.TransactionsByReceiptIdQuery = await _mediator.Send(searchByReceiptId);

        }

        private async Task SearchByCustomerSelfIdentifications(SalesTransactionSearchByQueries request, SalesTransactionSearchByQueriesResponse searchResponse)
        {
            var searchByCustomerIdentifications = new SalesTransactionSearchByCustomerSelfIdentificationsQuery()
            {
                SearchRequestId = request.SearchRequestId,
                CustomerId = request.Data.CustomerSelfIdentifications.CustomerId,
                CustomerIdType = request.Data.CustomerSelfIdentifications.CustomerIdType,
                CustomerIdCaptureReasonCodes = request.Data.CustomerSelfIdentifications?.CustomerIdCaptureReasonCodes,
                StartDate = request.Data.DateRange?.StartDate,
                EndDate = request.Data.DateRange?.EndDate
            };
            searchResponse.TransactionsByCustomerSelfIdentificationsQuery = await _mediator.Send(searchByCustomerIdentifications);
        }
    }
}

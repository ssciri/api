﻿using MediatR;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.API.Common;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Cloud.Sales360.Common.Logging;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.BL.Handlers.Query
{
    public class SalesTransactionSearchByCustomerSelfIdentificationsHandler : IRequestHandler<SalesTransactionSearchByCustomerSelfIdentificationsQuery, SalesTransactionsQueryResponse>
    {

        private ITransactionReadOnlyRepository _transactionRepository;
        public ILogger<SalesTransactionSearchByCustomerSelfIdentificationsHandler> _logger;

        public SalesTransactionSearchByCustomerSelfIdentificationsHandler(ITransactionReadOnlyRepository repository, ILogger<SalesTransactionSearchByCustomerSelfIdentificationsHandler> logger)
        {
            _transactionRepository = repository;
            _logger = logger;
        }
        public async Task<SalesTransactionsQueryResponse> Handle(SalesTransactionSearchByCustomerSelfIdentificationsQuery request, CancellationToken cancellationToken)
        {
            if (request.CustomerId == null || request.CustomerIdType == null)
                throw new ArgumentNullException();

            Stopwatch stwatch = new Stopwatch();
            stwatch.Start();
            IList<SalesTransaction> transactions;
            transactions = await _transactionRepository.GetTransactionByCustomerIdentifications(
                new SearchParameters
                {
                    CustomerId = request.CustomerId,
                    CustomerIdType = request.CustomerIdType,
                    CustomerIdCaptureReasonCodes = request.CustomerIdCaptureReasonCodes,
                    StartDate = request.StartDate,
                    EndDate = request.EndDate
                });
            stwatch.Stop();
            _logger.LogInformation(LoggingConstants.Template,
                                    "SalesTransactionSearchByCustomerSelfIdentificationsHandler",
                                    request.SearchRequestId,
                                    LoggingConstants.OperationName.SearchTransactionByCustomerIdentifications,
                                    LoggingConstants.EventCode.SearchByTransactionIdsSucceeded,
                                    stwatch.ElapsedMilliseconds,
                                    transactions?.Count
                                    );
            if (transactions == null || transactions.Count == 0)
                return CreateDefaultResponse();
            return CreateResponse(transactions);
        }

        private SalesTransactionsQueryResponse CreateDefaultResponse()
        {
            var result = new SalesTransactionsQueryResponse()
            {
                ErrorMessage = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND,
                StatusCode = Sales360Constants.ERROR_MESSAGE_ITEM_NOT_FOUND_STATUS_CODE
            };
            return result;
        }

        private SalesTransactionsQueryResponse CreateResponse(IList<SalesTransaction> transactions)
        {
            var result = new SalesTransactionsQueryResponse()
            {
                Data = transactions.ToList()
            };
            return result;
        }
    }
}

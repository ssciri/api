﻿using MediatR;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Cloud.Sales360.DAL.Read;
using Publix.Sales360.Models;
using System.Threading;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.BL.Query
{
    public class SalesTransactionSearchByTransactionIdHandler : IRequestHandler<SalesTransactionSearchByTransactionId, SalesTransaction>
    {
        private ITransactionReadOnlyRepository _transactionRepository;
        
        public SalesTransactionSearchByTransactionIdHandler(ITransactionReadOnlyRepository repository)
		{
            _transactionRepository = repository;            
        }

        public async Task<SalesTransaction> Handle(SalesTransactionSearchByTransactionId request, CancellationToken cancellationToken)
        {
            return await _transactionRepository.GetTransactionByTransactionId(request.transactionId);
        }
	}
}

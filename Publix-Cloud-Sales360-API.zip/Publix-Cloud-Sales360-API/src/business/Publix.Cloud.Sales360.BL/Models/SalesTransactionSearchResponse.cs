﻿using Newtonsoft.Json;
using Publix.Sales360.Models;
using System.Collections.Generic;


namespace Publix.Cloud.Sales360.BL.Models
{
  public  class SalesTransactionSearchResponse
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        public IList<SalesTransactionInfo> Transactions { get; set; }      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.BL.Models
{
	public class ApiSetting
	{

		public string Title { get; set; }
		public string Description { get; set; }
		public string Version { get; set; }
		public string ContactName { get; set; }
		public string ContactEmail { get; set; }
		public string ContactUrl { get; set; }
		public string ApiId { get; set; }
		public string Audience { get; set; }
		public string DataClassification { get; set; }

	}
}

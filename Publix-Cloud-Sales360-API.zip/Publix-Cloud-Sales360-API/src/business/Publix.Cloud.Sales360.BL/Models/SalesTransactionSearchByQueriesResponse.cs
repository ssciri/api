﻿using Newtonsoft.Json;
using Publix.Sales360.Models;
using System.Collections.Generic;


namespace Publix.Cloud.Sales360.BL.Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public  class SalesTransactionSearchByQueriesResponse
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        
        [JsonProperty("phonenumber_itemid_query_response")]
        public PhoneNumberQueryResponse TransactionsByPhoneNumberItemIdQuery { get; set; }

        [JsonProperty("transactionid_query_response")]
        public SalesTransactionsQueryResponse TransactionsByTransactionIdQuery { get; set; }

        [JsonProperty("partialcardnumber_query_response")]
        public PartialCardNumberQueryResponse TransactionsByPartialCardNoQuery { get; set; }

        [JsonProperty("receiptid_query_response")]
        public SalesTransactionsQueryResponse TransactionsByReceiptIdQuery { get; set; }

        [JsonProperty("customerSelfIdentifications_query_response")]
        public SalesTransactionsQueryResponse TransactionsByCustomerSelfIdentificationsQuery { get; set; }
    }
}

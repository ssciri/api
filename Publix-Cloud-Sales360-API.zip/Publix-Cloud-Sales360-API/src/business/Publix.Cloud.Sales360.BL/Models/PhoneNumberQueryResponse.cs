﻿using MediatR;
using Newtonsoft.Json;
using Publix.Sales360.Models;
using System.Collections.Generic;

namespace Publix.Cloud.Sales360.BL.Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PhoneNumberQueryResponse
    {
        public string StatusCode { get; set; }
        [JsonProperty("errormessage")]
        public string ErrorMessage { get; set; }
        [JsonProperty("data")]
        public List<SalesTransaction> Data { get; set; }
    }
}

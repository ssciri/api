﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class CreateSalesTransaction  : SalesTransaction, IRequest<SalesTransactionResponse>
    {
        public string Data { get; set; }
        
    }
}

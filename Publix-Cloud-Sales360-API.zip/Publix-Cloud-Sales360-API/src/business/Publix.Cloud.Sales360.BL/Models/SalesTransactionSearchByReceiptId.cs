﻿using MediatR;
using Publix.Sales360.Models;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class SalesTransactionSearchByReceiptId : IRequest<SalesTransaction>
    {
        public string ReceiptId { get; set; }

    }
}

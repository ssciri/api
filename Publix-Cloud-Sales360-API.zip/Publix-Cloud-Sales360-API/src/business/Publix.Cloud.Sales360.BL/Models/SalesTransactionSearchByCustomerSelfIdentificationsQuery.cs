﻿using MediatR;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class SalesTransactionSearchByCustomerSelfIdentificationsQuery: IRequest<SalesTransactionsQueryResponse>
    {  
        public string SearchRequestId { get; set; }
        public string[] CustomerId { get; set; }
        public Int32? CustomerIdType { get; set; }
        public int[] CustomerIdCaptureReasonCodes { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}

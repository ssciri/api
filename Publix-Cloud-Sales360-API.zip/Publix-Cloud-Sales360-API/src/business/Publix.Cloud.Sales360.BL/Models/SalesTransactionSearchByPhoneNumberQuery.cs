﻿using MediatR;
using Newtonsoft.Json;
using Publix.Sales360.Models;
using System;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class SalesTransactionSearchByPhoneNumberQuery : IRequest<PhoneNumberQueryResponse>
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        [JsonProperty("phonenumber")]
        public string PhoneNumber { get; set; }
        [JsonProperty("itemid")]
        public string[] ItemId { get; set; }
        [JsonProperty("startdate")]
        public DateTime? StartDate { get; set; }
        [JsonProperty("enddate")]
        public DateTime? EndDate { get; set; }
    }
}

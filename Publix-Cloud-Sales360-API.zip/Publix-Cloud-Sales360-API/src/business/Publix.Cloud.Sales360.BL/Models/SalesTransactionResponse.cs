﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.BL.Models
{
  public  class SalesTransactionResponse
    {
      
            public bool IsSuccess { get; set; }
            public string ErrorDescription { get; set; }

    }
}

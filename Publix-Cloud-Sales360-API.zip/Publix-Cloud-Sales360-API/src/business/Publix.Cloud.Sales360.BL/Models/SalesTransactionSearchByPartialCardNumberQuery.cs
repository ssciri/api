﻿using MediatR;
using Newtonsoft.Json;
using Publix.Sales360.Models;
using System;

namespace Publix.Cloud.Sales360.BL.Models
{
    public class SalesTransactionSearchByPartialCardNumberQuery : IRequest<PartialCardNumberQueryResponse>
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        [JsonProperty("firstsixcardno")]
        public string FirstSixCardNo { get; set; }
        [JsonProperty("lastfourcardno")]
        public string LastFourCardNo { get; set; }
        [JsonProperty("storeid")]
        public int? StoreId { get; set; }
        [JsonProperty("itemid")]
        public string[] ItemId { get; set; }
        [JsonProperty("startdate")]
        public DateTime? StartDate { get; set; }
        [JsonProperty("enddate")]
        public DateTime? EndDate { get; set; }
    }
}

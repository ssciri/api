﻿using MediatR;
using Newtonsoft.Json;
using System;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class SalesTransactionSearchByReceiptIdQuery : IRequest<SalesTransactionsQueryResponse>
    {
        [JsonProperty("receiptIds")]
        public string[] ReceiptIds { get; set; }       

    }
}

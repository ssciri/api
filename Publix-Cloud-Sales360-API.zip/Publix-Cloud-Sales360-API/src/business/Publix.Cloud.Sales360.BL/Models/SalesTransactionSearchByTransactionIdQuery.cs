﻿using MediatR;
using Newtonsoft.Json;
using System;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class SalesTransactionSearchByTransactionIdQuery : IRequest<SalesTransactionsQueryResponse>
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        [JsonProperty("transactionids")]
        public string[] TransactionIds { get; set; }       

    }
}

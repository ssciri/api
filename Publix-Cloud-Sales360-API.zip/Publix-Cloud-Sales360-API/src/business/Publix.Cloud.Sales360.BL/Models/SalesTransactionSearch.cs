﻿using MediatR;
using Newtonsoft.Json;

namespace Publix.Cloud.Sales360.BL.Models
{
   public class SalesTransactionSearch : IRequest<SalesTransactionSearchResponse>
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        [JsonProperty("transactionids")]
        public string[] TransactionIds { get; set; }
        
    }
}

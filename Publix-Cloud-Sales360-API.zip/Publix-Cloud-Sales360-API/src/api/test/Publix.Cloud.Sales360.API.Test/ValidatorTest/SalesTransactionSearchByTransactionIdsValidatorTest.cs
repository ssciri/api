using System;
using Xunit;
using Moq;
using Publix.Cloud.Sales360.API.Controllers;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Publix.Cloud.Sales360.BL.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.API.Validation;
using FluentValidation.Results;

namespace Publix.Cloud.Sales360.API.Test
{
    public class SalesTransactionSearchByTransactionIdsValidatorTest
    {

        private SalesTransactionSearchByTransactionIdsValidator Validator { get; }
        public SalesTransactionSearchByTransactionIdsValidatorTest()
        {
            Validator = new SalesTransactionSearchByTransactionIdsValidator();
        }

        [Fact]
        public void SalesTransactionSearchByTransactionIdsValidator_With_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearch() 
            { SearchRequestId = "1", TransactionIds = new string[] { "1", "2", "3" } };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByTransactionIdsValidator_With_EmtpyData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearch()
            { SearchRequestId = "1", TransactionIds = null };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'Transaction Ids' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByTransactionIdsValidator_With_Null()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearch()
            { SearchRequestId = null , TransactionIds = null };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 2);
            Assert.Equal("'Search Request Id' must not be empty.", result.Errors[0].ErrorMessage);
        }
    }
}

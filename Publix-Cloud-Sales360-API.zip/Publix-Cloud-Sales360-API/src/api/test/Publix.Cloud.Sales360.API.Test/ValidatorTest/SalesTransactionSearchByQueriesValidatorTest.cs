using System;
using Xunit;
using Moq;
using Publix.Cloud.Sales360.API.Controllers;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Publix.Cloud.Sales360.BL.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.API.Validation;
using FluentValidation.Results;

namespace Publix.Cloud.Sales360.API.Test
{
    public class SalesTransactionSearchByQueriesValidatorTest
    {

        private SalesTransactionSearchByQueriesValidator Validator { get; }
        public SalesTransactionSearchByQueriesValidatorTest()
        {
            Validator = new SalesTransactionSearchByQueriesValidator();
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_EmtpyData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            { SearchRequestId = "1", Queries = new string[] { "TransactionId" }, Data = null };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'data' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_NullFilter()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = null,
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 2);
            Assert.Equal("'queries' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_EmtpyFilter()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'queries' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_InvalidFilter()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "hello" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("queries does not support hello query", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_DuplicateFilter()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId", "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("queries contains duplicate value", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_DuplicateFilter_CaseInsensitive()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId", "transactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("queries contains duplicate value", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_TransactionId_With_NullTransactionId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = null
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'transactionid' must not be empty.", result.Errors[0].ErrorMessage);
        }


        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_TransactionId_With_EmptyTransactionId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'transactionid' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_TransactionId_With_InvalidDateRange()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1" },
                    DateRange = new DateRange { EndDate = DateTime.Parse("2021-03-09") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyPhoneNumber()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = null,
                    ItemId = new string[] { "1", "2" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'phonenumber' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyItemId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "test",
                    ItemId = new string[] { }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
            Assert.True(result.Errors.Count == 0);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyItemIdAndPhoneNo()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "",
                    ItemId = null
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'phonenumber' must not be empty.", result.Errors[0].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyStartDate()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "",
                    DateRange = new DateRange { EndDate = DateTime.Parse("2021-03-09") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 2);
            Assert.Equal("'phonenumber' must not be empty.", result.Errors[0].ErrorMessage);
            Assert.Equal("'startdate' must not be empty.", result.Errors[1].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyEndDate()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-09") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 2);
            Assert.Equal("'phonenumber' must not be empty.", result.Errors[0].ErrorMessage);
            Assert.Equal("'enddate' must not be empty.", result.Errors[1].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "test",
                    ItemId = new string[] { "1", "2" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyItemIdDateRange_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "test"
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_EmptyDateRange_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "test",
                    DateRange = null
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PhoneNoItemId_With_DateRange_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { },
                    PhoneNumber = "test",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-09"), EndDate = DateTime.Parse("2021-03-09") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_With_Null()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            { SearchRequestId = null, Queries = null, Data = null };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 4);
            Assert.Equal("'searchrequestid' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_EmptyItemId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    ItemId = new string[] { }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_EmptyItemInItemId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    ItemId = new string[] { "" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'itemid' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_EmptyItemIdAndStoreNo()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = null,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    ItemId = new string[] { }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'storeid' must not be empty.", result.Errors[0].ErrorMessage);

        }


        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_EmptyStartDate()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { EndDate = DateTime.Parse("2021-03-09") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'startdate' must not be empty.", result.Errors[0].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_EmptyEndDate()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-09") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'enddate' must not be empty.", result.Errors[0].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_InvalidEndDate()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { EndDate = default }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 2);
            Assert.Equal("'startdate' must not be empty.", result.Errors[0].ErrorMessage);
            Assert.Equal("'enddate' must not be empty.", result.Errors[1].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_InvalidDateRange()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-10"), EndDate = DateTime.Parse("2021-03-01") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("invalid date range", result.Errors[0].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_EmptyStartDateEndDate()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 2);
            Assert.Equal("'startdate' must not be empty.", result.Errors[0].ErrorMessage);
            Assert.Equal("'enddate' must not be empty.", result.Errors[1].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_EmptyItemIdAndStoreNoAndDateRange()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = null,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    ItemId = new string[] { },
                    DateRange = null
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'storeid' must not be empty.", result.Errors[0].ErrorMessage);

        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_ItemId_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    ItemId = new string[] { "1", "2", "3" },
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876"
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_ItemId_DateRange_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    ItemId = new string[] { "1", "2", "3" },
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-10"), EndDate = DateTime.Parse("2021-03-10") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021-03-10"), EndDate = DateTime.Parse("2021-03-10") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_DateRange_DifferentFormat_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876",
                    DateRange = new DateRange { StartDate = DateTime.Parse("2021/03/10"), EndDate = DateTime.Parse("2021/03/10") }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_PartialCard_With_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "3",
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = 1234,
                    FirstSixCardNo = "123456",
                    LastFourCardNo = "9876"
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_ReceiptId_With_NullReceiptId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "ReceiptId" },
                Data = new SearchData()
                {
                    ReceiptId = null
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'receiptid' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_ReceiptId_With_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "ReceiptId" },
                Data = new SearchData()
                {
                    ReceiptId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_ReceiptId_With_DuplicateData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "ReceiptId", "ReceiptId" },
                Data = new SearchData()
                {
                    ReceiptId = new string[] { "1", "2", "3" }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("queries contains duplicate value", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_CustomerIdentifications_With_NullCustomerId()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications = new CustomerSelfIdentifications
                    {
                        CustomerId = null,
                        CustomerIdCaptureReasonCodes = new int[1],
                        CustomerIdType = 1

                    }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'customerId' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_CustomerIdentifications_With_NullCustomerIdType()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications = new CustomerSelfIdentifications
                    {
                        CustomerId = new string[] { "1", "2", "3" },
                        CustomerIdCaptureReasonCodes = new int[1],
                        CustomerIdType = null

                    }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("'customerIdType' must not be empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_CustomerIdentifications_With_ValidData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications = new CustomerSelfIdentifications
                    {
                        CustomerId = new string[] { "1", "2", "3" },
                        CustomerIdCaptureReasonCodes = new int[ 1],
                        CustomerIdType = 1
                    }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void SalesTransactionSearchByQueriesValidator_Filter_CustomerIdentifications_With_DuplicateData()
        {
            // Arrange
            var transactionCommand = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "customerselfidentifications", "customerselfidentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications = new CustomerSelfIdentifications
                    {
                        CustomerId = new string[] { "1", "2", "3" },
                        CustomerIdCaptureReasonCodes = new int[ 1],
                        CustomerIdType = 1
                    }
                }
            };

            // Act
            ValidationResult result = Validator.Validate(transactionCommand);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count == 1);
            Assert.Equal("queries contains duplicate value", result.Errors[0].ErrorMessage);
        }

    }
}

using System;
using Xunit;
using Moq;
using Publix.Cloud.Sales360.API.Controllers;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Sales360.Models;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace Publix.Cloud.Sales360.API.Test
{
    public class TransactionControllerTest
    {
        [Fact]
        public void Test_SalesTransactionSearchByTransactionIds_With_ValidData()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController>>();

            var request = new SalesTransactionSearch()
            {
                SearchRequestId = "1",
                TransactionIds = new string[] { "1", "2", "3" }
            };

            var expectedResponse = new SalesTransactionSearchResponse()
            { 
                SearchRequestId = "1",
                Transactions = new List<SalesTransactionInfo>()
            };

            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearch>(), default))
                .Returns(Task.FromResult<SalesTransactionSearchResponse>(expectedResponse))
                .Verifiable();

            var handler = new TransactionController(mockMediator.Object, mockLogger.Object);

            // Act
            var actualResponse = handler.SearchByTransactionIds(request).Result;

            // Assert
            mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearch>(), default), Times.Once());
            Assert.NotNull(actualResponse);
            var model = Assert.IsAssignableFrom<SalesTransactionSearchResponse>((actualResponse.Result as OkObjectResult).Value);
            Assert.Equal(request.SearchRequestId, model.SearchRequestId);
            Assert.Empty(model.Transactions);
        }
    }
}

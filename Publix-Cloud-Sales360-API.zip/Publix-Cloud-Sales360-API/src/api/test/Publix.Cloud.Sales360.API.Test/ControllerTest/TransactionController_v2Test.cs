using System;
using Xunit;
using Moq;
using Publix.Cloud.Sales360.API.Controllers;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Sales360.Models;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace Publix.Cloud.Sales360.API.Test
{
    public class TransactionController_v2Test
    {
        [Fact]
        public void Test_SalesTransactionSearchByQueries_With_FilterBy_TransactionId()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController_v2>>();

            var request = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData() { TransactionId = new string[] { "1", "2", "3" } }
            };

            var expectedResponse = new SalesTransactionSearchByQueriesResponse()
            {
                SearchRequestId = "1",
                TransactionsByPartialCardNoQuery = null,
                TransactionsByPhoneNumberItemIdQuery = null,
                TransactionsByTransactionIdQuery = new SalesTransactionsQueryResponse()
            };

            //var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByQueries>(), default))
                .Returns(Task.FromResult<SalesTransactionSearchByQueriesResponse>(expectedResponse))
                .Verifiable();

            var handler = new TransactionController_v2(mockMediator.Object, mockLogger.Object);

            // Act
            var actualResponse = handler.SearchByQueries(request).Result;

            // Assert
            mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByQueries>(), default), Times.Once());
            Assert.NotNull(actualResponse);
            var model = Assert.IsAssignableFrom<SalesTransactionSearchByQueriesResponse>((actualResponse.Result as OkObjectResult).Value);
            Assert.Equal(request.SearchRequestId, model.SearchRequestId);
            Assert.Null(model.TransactionsByPartialCardNoQuery);
            Assert.Null(model.TransactionsByPhoneNumberItemIdQuery);
            Assert.NotNull(model.TransactionsByTransactionIdQuery);
        }


        [Fact]
        public void Test_SalesTransactionSearchByQueries_With_FilterBy_PhoneNumberAndItemId()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController_v2>>();

            var request = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "Phonenumber_ItemId" },
                Data = new SearchData() { ItemId= new string[] { "1", "2", "3" } , PhoneNumber = "1234"}
            };

            var expectedResponse = new SalesTransactionSearchByQueriesResponse()
            {
                SearchRequestId = "1",
                TransactionsByPartialCardNoQuery = null,
                TransactionsByPhoneNumberItemIdQuery =  new PhoneNumberQueryResponse() { 
                    Data = new List<SalesTransaction>()                    
                },
                TransactionsByTransactionIdQuery = null
            };

            //var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByQueries>(), default))
                .Returns(Task.FromResult<SalesTransactionSearchByQueriesResponse>(expectedResponse))
                .Verifiable();

            var handler = new TransactionController_v2(mockMediator.Object, mockLogger.Object);

            // Act
            var actualResponse = handler.SearchByQueries(request).Result;

            // Assert
            mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByQueries>(), default), Times.Once());
            Assert.NotNull(actualResponse);
            var model = Assert.IsAssignableFrom<SalesTransactionSearchByQueriesResponse>((actualResponse.Result as OkObjectResult).Value);
            Assert.Equal(request.SearchRequestId, model.SearchRequestId);
            Assert.Null(model.TransactionsByPartialCardNoQuery);
            Assert.NotNull(model.TransactionsByPhoneNumberItemIdQuery);
            Assert.Null(model.TransactionsByTransactionIdQuery);
        }


        [Fact]
        public void Test_SalesTransactionSearchByQueries_With_FilterBy_PhoneNumberAndItemId_AND_TransactionId()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController_v2>>();

            var request = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId", "Phonenumber_ItemId" },
                Data = new SearchData() { 
                    TransactionId = new string[] { "1", "2", "3" },
                    ItemId = new string[] { "1", "2", "3" }, 
                    PhoneNumber = "1234" }
            };

            var expectedResponse = new SalesTransactionSearchByQueriesResponse()
            {
                SearchRequestId = "1",
                TransactionsByPartialCardNoQuery = null,
                TransactionsByPhoneNumberItemIdQuery = new PhoneNumberQueryResponse()
                {
                    Data = new List<SalesTransaction>()
                },
                TransactionsByTransactionIdQuery = new SalesTransactionsQueryResponse()
                {
                    Data = new List<SalesTransaction>()
                }
            };

            //var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByQueries>(), default))
                .Returns(Task.FromResult<SalesTransactionSearchByQueriesResponse>(expectedResponse))
                .Verifiable();

            var handler = new TransactionController_v2(mockMediator.Object, mockLogger.Object);

            // Act
            var actualResponse = handler.SearchByQueries(request).Result;

            // Assert
            mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByQueries>(), default), Times.Once());
            Assert.NotNull(actualResponse);
            var model = Assert.IsAssignableFrom<SalesTransactionSearchByQueriesResponse>((actualResponse.Result as OkObjectResult).Value);
            Assert.Equal(request.SearchRequestId, model.SearchRequestId);
            Assert.Null(model.TransactionsByPartialCardNoQuery);
            Assert.NotNull(model.TransactionsByPhoneNumberItemIdQuery);
            Assert.NotNull(model.TransactionsByTransactionIdQuery);
        }

        [Fact]
        public void Test_SalesTransactionSearchByQueries_With_FilterBy_PhoneNumberAndItemId_AND_TransactionId_OneQueryException()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController_v2>>();

            var request = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "TransactionId", "Phonenumber_ItemId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "1", "2", "3" },
                    ItemId = new string[] { "1", "2", "3" },
                    PhoneNumber = "1234"
                }
            };

            var expectedResponse = new SalesTransactionSearchByQueriesResponse()
            {
                SearchRequestId = "1",
                TransactionsByPartialCardNoQuery = null,
                TransactionsByPhoneNumberItemIdQuery = new PhoneNumberQueryResponse()
                {
                    Data = new List<SalesTransaction>()
                },
                TransactionsByTransactionIdQuery = new SalesTransactionsQueryResponse()
                {
                    Data = new List<SalesTransaction>()
                }
            };

            //var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByQueries>(), default))
                .ThrowsAsync(new Exception())
                .Verifiable();

            var handler = new TransactionController_v2(mockMediator.Object, mockLogger.Object);

            // Act and assert
            Assert.ThrowsAsync<Exception>(async ()=> await handler.SearchByQueries(request));

        }

        [Fact]
        public void Test_SalesTransactionSearchByQueries_With_FilterBy_ReceiptId()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController_v2>>();

            var request = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "ReceiptId" },
                Data = new SearchData() { ReceiptId = new string[] { "1", "2", "3" } }
            };

            var expectedResponse = new SalesTransactionSearchByQueriesResponse()
            {
                SearchRequestId = "1",
                TransactionsByPartialCardNoQuery = null,
                TransactionsByPhoneNumberItemIdQuery = null,
                TransactionsByTransactionIdQuery = null,
                TransactionsByReceiptIdQuery = new SalesTransactionsQueryResponse()
            };

            //var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByQueries>(), default))
                .Returns(Task.FromResult<SalesTransactionSearchByQueriesResponse>(expectedResponse))
                .Verifiable();

            var handler = new TransactionController_v2(mockMediator.Object, mockLogger.Object);

            // Act
            var actualResponse = handler.SearchByQueries(request).Result;

            // Assert
            mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByQueries>(), default), Times.Once());
            Assert.NotNull(actualResponse);
            var model = Assert.IsAssignableFrom<SalesTransactionSearchByQueriesResponse>((actualResponse.Result as OkObjectResult).Value);
            Assert.Equal(request.SearchRequestId, model.SearchRequestId);
            Assert.Null(model.TransactionsByPartialCardNoQuery);
            Assert.Null(model.TransactionsByPhoneNumberItemIdQuery);
            Assert.Null(model.TransactionsByTransactionIdQuery);
            Assert.NotNull(model.TransactionsByReceiptIdQuery);
        }

        [Fact]
        public void Test_SalesTransactionSearchByQueries_With_FilterBy_CustomerIdentifications()
        {
            var mockMediator = new Mock<IMediator>();
            var mockLogger = new Mock<ILogger<TransactionController_v2>>();

            var request = new SalesTransactionSearchByQueries()
            {
                SearchRequestId = "1",
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData() {
                   CustomerSelfIdentifications= new BL.Models.CustomerSelfIdentifications
                   {
                       CustomerId= new string[] { "1", "2", "3" }
                   }
                }
            };

            var expectedResponse = new SalesTransactionSearchByQueriesResponse()
            {
                SearchRequestId = "1",
                TransactionsByPartialCardNoQuery = null,
                TransactionsByPhoneNumberItemIdQuery = null,
                TransactionsByTransactionIdQuery = null,
                TransactionsByReceiptIdQuery = null,
                TransactionsByCustomerSelfIdentificationsQuery= new SalesTransactionsQueryResponse()
            };

            //var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockMediator.Setup(repo => repo.Send(It.IsAny<SalesTransactionSearchByQueries>(), default))
                .Returns(Task.FromResult<SalesTransactionSearchByQueriesResponse>(expectedResponse))
                .Verifiable();

            var handler = new TransactionController_v2(mockMediator.Object, mockLogger.Object);

            // Act
            var actualResponse = handler.SearchByQueries(request).Result;

            // Assert
            mockMediator.Verify(x => x.Send(It.IsAny<SalesTransactionSearchByQueries>(), default), Times.Once());
            Assert.NotNull(actualResponse);
            var model = Assert.IsAssignableFrom<SalesTransactionSearchByQueriesResponse>((actualResponse.Result as OkObjectResult).Value);
            Assert.Equal(request.SearchRequestId, model.SearchRequestId);
            Assert.Null(model.TransactionsByPartialCardNoQuery);
            Assert.Null(model.TransactionsByPhoneNumberItemIdQuery);
            Assert.Null(model.TransactionsByTransactionIdQuery);
            Assert.Null(model.TransactionsByReceiptIdQuery);
            Assert.NotNull(model.TransactionsByCustomerSelfIdentificationsQuery);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class SearchByTransactionIdsValidator : AbstractValidator<SearchData>
	{
		public SearchByTransactionIdsValidator()
		{
			RuleFor(x => x).NotEmpty();
			RuleFor(y => y.TransactionId).NotEmpty().WithName("transactionid");
			RuleForEach(y => y.TransactionId).NotEmpty().WithName("transactionid");			
		}
	}
}

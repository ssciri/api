﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class SearchByReceiptIdValidator : AbstractValidator<SearchData>
	{
		public SearchByReceiptIdValidator()
		{
			RuleFor(x => x).NotEmpty();
			RuleFor(y => y.ReceiptId).NotEmpty().WithName("receiptid");
			RuleForEach(y => y.ReceiptId).NotEmpty().WithName("receiptid");			
		}
	}
}
     
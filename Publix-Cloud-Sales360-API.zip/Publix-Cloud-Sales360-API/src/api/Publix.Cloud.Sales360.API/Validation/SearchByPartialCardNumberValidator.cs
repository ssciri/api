﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class SearchByPartialCardNumberValidator : AbstractValidator<SearchData>
	{
		public SearchByPartialCardNumberValidator()
		{
			RuleFor(x => x).NotEmpty();
			RuleFor(y => y.FirstSixCardNo).NotEmpty().Length(6).WithName("firstsixcardno");
			RuleFor(y => y.LastFourCardNo).NotEmpty().Length(4).WithName("lastfourcardno");
			RuleFor(y => y.StoreId).NotEmpty().WithName("storeid");
			RuleForEach(y => y.ItemId).NotEmpty().WithName("itemid");
			When(x => x.DateRange != null, () =>
			{
				RuleFor(y => y.DateRange).SetValidator(new DateRangeValidator()).OverridePropertyName("daterange");
			});
		}
	}
}

using FluentValidation;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Dynamic;
using System.Collections.Generic;
using Publix.Cloud.Sales360.BL.Models;
using System;
using FluentValidation.Validators;
using FluentValidation.Results;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class SalesTransactionSearchByTransactionIdsValidator : AbstractValidator<SalesTransactionSearch>
	{
		public SalesTransactionSearchByTransactionIdsValidator()
		{
			RuleFor(x => x).NotEmpty();
			RuleFor(x => x.SearchRequestId).NotEmpty();
			RuleFor(x => x.TransactionIds).NotEmpty();
				
		}
	}

}
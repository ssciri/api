﻿using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.API.Validation
{
    public class CustomerSelfIdentificationsValidator : AbstractValidator<CustomerSelfIdentifications>
    {
        public CustomerSelfIdentificationsValidator()
        {
            RuleFor(y => y.CustomerId).NotEmpty().WithName("customerId");
            RuleFor(y => y.CustomerIdType).NotEmpty().WithName("customerIdType");
            RuleForEach(y => y.CustomerId).NotEmpty().WithName("customerId");
        }
    }
}

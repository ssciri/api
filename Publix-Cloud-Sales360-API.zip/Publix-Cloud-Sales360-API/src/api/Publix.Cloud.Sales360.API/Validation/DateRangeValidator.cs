﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class DateRangeValidator : AbstractValidator<DateRange>
	{
		public DateRangeValidator()
		{
			RuleFor(y => y.StartDate).NotEmpty().WithName("startdate");
			RuleFor(y => y.StartDate).Must(BeAValidDate).When(m => m.StartDate.HasValue)
			.WithMessage("{PropertyName} contains invalid value").WithName("startdate");
			RuleFor(y => y.EndDate).NotEmpty().WithName("enddate");
			RuleFor(y => y.EndDate).Must(BeAValidDate).When(m => m.EndDate.HasValue)
				.WithMessage("{PropertyName} contains invalid value").WithName("enddate");
			When(m => m.StartDate.HasValue && m.EndDate.HasValue, () => RuleFor(y => y).Must(fooArgs =>
			ValidDateRange(fooArgs.StartDate, fooArgs.EndDate)).WithMessage("invalid date range")
			);
		}

		private bool BeAValidDate(DateTime? val)
		{
			return val.Value != default;			
		}

		private bool ValidDateRange(DateTime? startDate, DateTime? endDate)
		{
			return (endDate >= startDate);
		}
	}
}

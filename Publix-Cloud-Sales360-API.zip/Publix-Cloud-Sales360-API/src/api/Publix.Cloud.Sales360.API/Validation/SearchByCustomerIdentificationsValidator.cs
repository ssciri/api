﻿using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.API.Validation
{
    public class SearchByCustomerIdentificationsValidator : AbstractValidator<SearchData>
    {
        public SearchByCustomerIdentificationsValidator()
        {
            RuleFor(x => x).NotEmpty();
            RuleFor(x => x.CustomerSelfIdentifications).NotEmpty();
            When(x => x.DateRange != null, () =>
            {  
                RuleFor(y => y.DateRange).SetValidator(new DateRangeValidator()).OverridePropertyName("daterange");
            });
            When(x => x.CustomerSelfIdentifications != null, () =>
            {
                RuleFor(y => y.CustomerSelfIdentifications).SetValidator(new CustomerSelfIdentificationsValidator()).OverridePropertyName("customerSelfIdentifications");
            });
        }
    }
}

using FluentValidation;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Dynamic;
using System.Collections.Generic;
using Publix.Cloud.Sales360.BL.Models;
using System;
using FluentValidation.Validators;
using FluentValidation.Results;
using System.Linq;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class SalesTransactionSearchByQueriesValidator : AbstractValidator<SalesTransactionSearchByQueries>
	{
		public SalesTransactionSearchByQueriesValidator()
		{
			RuleFor(x => x).NotEmpty();
			RuleFor(x => x.SearchRequestId).NotEmpty().WithName("searchrequestid");
			//RuleFor(x => x.Filter_By).NotEmpty().WithName("filter_by");
			RuleFor(y => y.Data).NotEmpty().WithName("data");
			RuleFor(x => x.Queries).NotEmpty()
				.Must(c => c !=null && !c.GroupBy(y => y.ToLower()).Any(x => x.Count() > 1))
				.WithMessage("{PropertyName} contains duplicate value").WithName("queries");
			
			RuleForEach(x => x.Queries).NotEmpty().IsEnumName(typeof(QueryName), caseSensitive: false).WithName("queries")
				.WithMessage("{PropertyName} does not support {PropertyValue} query").OverridePropertyName("queries");


			When(x => x.Queries != null && x.Queries.ToList().Exists(c => c.ToLower() == "phonenumber"), () =>
			{
				RuleFor(y => y.Data).SetValidator(new SearchByPhoneNumberAndItemIdValidator()).OverridePropertyName("data");				
			});
			When(x => x.Queries != null && x.Queries.ToList().Exists(c => c.ToLower() == "transactionid"), () =>
			{
				RuleFor(y => y.Data).SetValidator(new SearchByTransactionIdsValidator()).OverridePropertyName("data");				
			});
			When(x => x.Queries != null && x.Queries.ToList().Exists(c => c.ToLower() == "partialcardnumber"), () =>
			{ 
				RuleFor(y => y.Data).SetValidator(new SearchByPartialCardNumberValidator()).OverridePropertyName("data");
			});
			When(x => x.Queries != null && x.Queries.ToList().Exists(c => c.ToLower() == "receiptid"), () =>
			{
				RuleFor(y => y.Data).SetValidator(new SearchByReceiptIdValidator()).OverridePropertyName("data");
			});
			When(x => x.Queries != null && x.Queries.ToList().Exists(c => c.ToLower() == "customerselfidentifications"), () =>
			{
				RuleFor(y => y.Data).SetValidator(new SearchByCustomerIdentificationsValidator()).OverridePropertyName("data");
				
			});
		}
	}
}
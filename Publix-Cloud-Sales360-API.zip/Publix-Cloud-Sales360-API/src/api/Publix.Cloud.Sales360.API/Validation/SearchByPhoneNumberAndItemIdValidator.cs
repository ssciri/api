﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Publix.Cloud.Sales360.BL.Models;
using System.Linq;

namespace Publix.Cloud.Sales360.API.Validation
{
	public class SearchByPhoneNumberAndItemIdValidator : AbstractValidator<SearchData>
	{
		public SearchByPhoneNumberAndItemIdValidator()
		{
			RuleFor(x => x).NotEmpty();
			RuleFor(y => y.PhoneNumber).NotEmpty().WithName("phonenumber");
			When(x => x.DateRange != null , () =>
			{
				RuleFor(y => y.DateRange).SetValidator(new DateRangeValidator()).OverridePropertyName("daterange");
			});
		}

		
	}
}

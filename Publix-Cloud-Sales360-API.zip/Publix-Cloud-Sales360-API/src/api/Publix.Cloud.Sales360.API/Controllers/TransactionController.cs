﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Sales360.Models;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.API.Controllers
{
    [Route("sales-transactions")]
    [ApiController]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ApiVersion("1.0",Deprecated = true)]
    [ApiExplorerSettings(GroupName = "v1")]
    [Authorize]
    public class TransactionController : ControllerBase
    {
        private readonly IMediator _mediator;
        public ILogger<TransactionController> _logger;

        public TransactionController(IMediator mediator, ILogger<TransactionController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Return the sales transactions based on list of transactionIds.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Retun the list of sales transactions</returns>
        /// <response code="200">Return the sales transactions.</response>
        /// <response code="400">Bad request.</response>
        [HttpPost("search")]
        //[Route("sales-transactions/search")]
        public async Task<ActionResult<SalesTransactionSearchResponse>> SearchByTransactionIds([FromBody] SalesTransactionSearch request)
        {
            var response = await _mediator.Send(request);
            return Ok(response);
        }

        /// <summary>
        /// Return the sales transaction based on transactionId.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return the sales transaction.</returns>
        /// <remarks>
        /// Sample request:
        ///
        ///     Get /sales-transactions/202021
        ///
        /// </remarks>
        /// <response code="200">Return the sales transaction.</response>
        /// <response code="400">Bad request.</response>
        /// <response code="422">Sales transaction not found.</response>
        [HttpGet("{transactionId}")]
        public async Task<ActionResult<SalesTransaction>> Get([FromRoute] SalesTransactionSearchByTransactionId request)
        {
            var response = await _mediator.Send(request);
            if (response == null)
                return StatusCode(422,"Sales transaction not found");
            return Ok(response);
        }
    }
}

﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Models;
using Publix.Sales360.Models;
using System.Threading.Tasks;


namespace Publix.Cloud.Sales360.API.Controllers
{
    [Route("sales-transactions")]
    [ApiController]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ApiVersion("2.0")]
    [ApiExplorerSettings(GroupName = "v2")]
    [Authorize]
    public class TransactionController_v2 : ControllerBase
    {
        private readonly IMediator _mediator;
        public ILogger<TransactionController_v2> _logger;

        public TransactionController_v2(IMediator mediator, ILogger<TransactionController_v2> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Return the sales transactions based on search criteria.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Retun the list of sales transactions</returns>
        /// <response code="200">Return the sales transactions.</response>
        /// <response code="400">Bad request.</response>
        [HttpPost("search")]
        //[Route("sales-transactions/search")]
        public async Task<ActionResult<SalesTransactionSearchByQueriesResponse>> SearchByQueries([FromBody] SalesTransactionSearchByQueries request)
        {
            var response = await _mediator.Send(request);
            return Ok(response);
        }
    }
}

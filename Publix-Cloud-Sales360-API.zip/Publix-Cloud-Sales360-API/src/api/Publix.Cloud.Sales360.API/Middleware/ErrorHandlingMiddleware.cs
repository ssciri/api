﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.BL.Models;

namespace Publix.Cloud.Sales360.API.Middleware
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ErrorHandlingMiddleware> _logger;

        public ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context, IWebHostEnvironment env)
        {
            string eventId = null;
            try
            {
                eventId = await LogRequestAsync(context);
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(eventId, context, env, ex);
            }
        }


        private async Task<string> LogRequestAsync(HttpContext context)
        {
            var method = context.Request.Method;

            // Ensure the request body can be read multiple times
            context.Request.EnableBuffering();

            // Only if we are dealing with POST or PUT, GET and others shouldn't have a body
            if (context.Request.Body.CanRead && (method == HttpMethods.Post || method == HttpMethods.Put))
            {
                // Leave stream open so next middleware can read it
                using var reader = new StreamReader(
                    context.Request.Body,
                    Encoding.UTF8,
                    detectEncodingFromByteOrderMarks: false,
                    bufferSize: 512, leaveOpen: true);

                var requestBody = await reader.ReadToEndAsync();

                // Reset stream position, so next middleware can read it
                context.Request.Body.Position = 0;

                // Log request body
                var result = JsonSerializer.Deserialize<SalesTransactionSearch>(requestBody);
                var eventId = result?.SearchRequestId ?? context?.TraceIdentifier;
                _logger.LogInformation($"{"EventId: " + eventId},RequestBody: {requestBody}");
                return eventId;
            }
            return context?.TraceIdentifier;
        }

        private Task HandleExceptionAsync(string eventId, HttpContext context, IWebHostEnvironment env, Exception exception)
        {
            _logger.LogError($"{"EventId: " + eventId} Sales360 Exception: {exception}");

            var stackTrace = String.Empty;

            context.Response.ContentType = "application/json";

            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            if (exception is UnauthorizedAccessException)
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;

            if (env.IsEnvironment("Development"))
                stackTrace = exception.StackTrace;

            var result = JsonSerializer.Serialize(new
            {
                title = "Internal Server Error.",
                status = (int)HttpStatusCode.InternalServerError,
                traceId = eventId,
                stackTrace
            });
            return context.Response.WriteAsync(result);
        }

    }

}

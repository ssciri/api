using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MediatR;
using System.Reflection;
using Publix.Cloud.Sales360.API.PipelineBehaviors;
using FluentValidation.AspNetCore;
using Publix.Cloud.Sales360.API.Validation;
using Microsoft.AspNetCore.Mvc.Versioning;
using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Cloud.Sales360.BL.Query;
using Publix.Cloud.Sales360.DAL.Read;
using Microsoft.OpenApi.Models;
using System.IO;
using Microsoft.OpenApi.Interfaces;
using Microsoft.OpenApi.Any;
using Publix.Cloud.Sales360.API.Swagger;
using Publix.Cloud.Sales360.API.Middleware;
using Publix.Cloud.Sales360.BL.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Identity.Web;
using System.Diagnostics.Tracing;
using Publix.Cloud.Sales360.API.Common;
using Newtonsoft.Json.Serialization;

namespace Publix.Cloud.Sales360.API
{
    public class Startup
    {

        private IWebHostEnvironment CurrentEnvironment { get; set; }

        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            Configuration = configuration;
            CurrentEnvironment = env;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));
            services.AddMediatR(Assembly.GetAssembly(typeof(SalesTransactionSearchByTransactionIdsHandler)));

            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));

            services.AddControllers()
                .AddFluentValidation(fv => fv.RegisterValidatorsFromAssemblyContaining<SalesTransactionSearchByTransactionIdsValidator>())
                //.AddJsonOptions(opt => opt.JsonSerializerOptions.PropertyNamingPolicy = null);
            .AddNewtonsoftJson(x => {
                 // My config is Pascal Case
                 x.SerializerSettings.ContractResolver = new DefaultContractResolver();
             });

            services.AddApiVersioning(config =>
            {
                config.DefaultApiVersion = new ApiVersion(1, 0);
                config.AssumeDefaultVersionWhenUnspecified = true;
                config.ReportApiVersions = true;
                config.ApiVersionReader = new MediaTypeApiVersionReader("version");

            });

            services.AddSingleton(typeof(ICosmosAPI), typeof(CosmosAPI));

            services.AddSingleton(typeof(ITransactionReadOnlyRepository), typeof(TransactionReadOnlyRepository));

            services.AddApplicationInsightsTelemetry();

			if (CurrentEnvironment.IsDevelopment())
			{

				services.Configure<ApiSetting>(Configuration.GetSection(nameof(ApiSetting)));
				var settings = Configuration.GetSection(nameof(ApiSetting)).Get<ApiSetting>();

				services.AddSwaggerGen(c =>
				{
					c.SwaggerDoc("v1", new OpenApiInfo
					{
						Version = "v1",
						Title = settings.Title,
						Description = settings.Description,
						Contact = new OpenApiContact
						{
							Name = settings.ContactName,
							Email = settings.ContactEmail,
							Url = new Uri(settings.ContactUrl)
						},
						Extensions = new Dictionary<string, IOpenApiExtension>
						{
						{"x-api-id", new OpenApiString(settings.ApiId) },
						{"x-audience", new OpenApiString(settings.Audience) },
						{ "x-data-classification", new OpenApiString(settings.DataClassification) }
						}
					});

                    c.SwaggerDoc("v2", new OpenApiInfo
                    {
                        Version = "v2",
                        Title = settings.Title,
                        Description = settings.Description,
                        Contact = new OpenApiContact
                        {
                            Name = settings.ContactName,
                            Email = settings.ContactEmail,
                            Url = new Uri(settings.ContactUrl)
                        },
                        Extensions = new Dictionary<string, IOpenApiExtension>
                        {
                        {"x-api-id", new OpenApiString(settings.ApiId) },
                        {"x-audience", new OpenApiString(settings.Audience) },
                        { "x-data-classification", new OpenApiString(settings.DataClassification) }
                        }
                    });

                    c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
                    c.DocInclusionPredicate((docName, apiDesc) => apiDesc.GroupName == docName);
                    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
					var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
					c.IncludeXmlComments(xmlPath);
					c.SchemaFilter<SalesTransactionSchemaFilter>();
				});
            }
            services.AddSwaggerGenNewtonsoftSupport();


            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
				.AddMicrosoftIdentityWebApi(Configuration, Sales360Constants.APPSETTING_APP_REGISTRATION_SECTION_NAME, 
                JwtBearerDefaults.AuthenticationScheme, Configuration.GetValue<bool>(Sales360Constants.APPSETTING_APP_REGISTRATION_ENABLE_DIAGNOSTICS));

			services.Configure<JwtBearerOptions>(options =>
            {
                var existingOnTokenValidatedHandler = options.Events.OnTokenValidated;
                options.Events.OnTokenValidated = async context =>
                {
                    await existingOnTokenValidatedHandler(context);
                    Configuration.Bind(Sales360Constants.APPSETTING_APP_REGISTRATION_SECTION_NAME, options);
                    options.TokenValidationParameters.ValidateAudience = true;
                    options.TokenValidationParameters.ValidateIssuer = true;
                    options.TokenValidationParameters.ValidateLifetime = true;
                    options.TokenValidationParameters.ValidateIssuerSigningKey = true;
                    options.TokenValidationParameters.ValidIssuers = Configuration[Sales360Constants.APPSETTING_APP_REGISTRATION_VALD_ISSUERS].Split(',').ToList();  //Support multiple Audiences
                    options.TokenValidationParameters.ValidAudiences = Configuration[Sales360Constants.APPSETTING_APP_REGISTRATION_VALD_AUDIENCES].Split(',').ToList();  //Support Multiple Issuers/Tenants
                };
            });

            services.AddHealthChecks().
                AddCosmosDb(Configuration.GetConnectionString(Sales360Constants.APPSETTING_COSMOS_CONNECTIONSTRING));

        }

        
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            Microsoft.IdentityModel.Logging.IdentityModelEventSource.Logger.LogLevel = Configuration.GetValue<EventLevel>(Sales360Constants.APPSETTING_APP_REGISTRATION_LOG_LEVEL);
            Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = Configuration.GetValue<bool>(Sales360Constants.APPSETTING_APP_REGISTRATION_ENABLE_DIAGNOSTICS);
            if (env.IsDevelopment())
            {
                app.UseSwagger();
                //app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Sales 360 v1"));
                app.UseSwaggerUI(c => { c.SwaggerEndpoint("v1/swagger.json", "Sales 360 v1");
                    c.SwaggerEndpoint("v2/swagger.json", "Sales 360 v2");});
                
            }
            else
            {
                app.UseHsts();
            }

            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseCors("MyPolicy");
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health");
                endpoints.MapControllers();
            });

        }
    }
}

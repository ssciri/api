﻿using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.API.Swagger
{
    public class SalesTransactionSchemaFilter : ISchemaFilter
    {
        private class TransactionSchemaInfo
        {
            public string format;
            public string example;
        }

        private Dictionary<string, TransactionSchemaInfo> schemaPropertyPatterns = new Dictionary<string, TransactionSchemaInfo>()
        {
            { "utc", new TransactionSchemaInfo(){format = "date-time", example = "1994-11-05T13:15:30Z"  } },
            { "timelocal", new TransactionSchemaInfo(){format = "date-time", example = "2021-01-07T15:48:20.0000000-05:00"  } },
            { "price", new TransactionSchemaInfo(){format = "decimal", example = "40.99"  }},
            { "amount", new TransactionSchemaInfo(){format = "decimal", example = "40.99"  }},
            { "date", new TransactionSchemaInfo(){format = "date", example = "2014-03-22"  }}
        };

        public void Apply(OpenApiSchema schema, SchemaFilterContext context)
        {
            foreach (var propertPattern in schemaPropertyPatterns)
            {
                schema.Properties.Keys.Where(c => c.ToLower().Contains(propertPattern.Key)).ToList()
					.ForEach(property =>
                    {
                        var p = schema.Properties[property];
                        if (string.IsNullOrWhiteSpace(p.Format))
                        {
                            p.Format = propertPattern.Value.format;
                            p.Example = new OpenApiString(propertPattern.Value.example);
                        }
                    });
            }           
        }

    }
}

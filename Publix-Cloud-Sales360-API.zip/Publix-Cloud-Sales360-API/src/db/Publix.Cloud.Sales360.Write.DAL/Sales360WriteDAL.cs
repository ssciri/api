﻿using Publix.Cloud.Sales360.Common.Cosmos;
using Microsoft.Extensions.Logging;

namespace Publix.Cloud.Sales360.Write.DAL
{
    public class Sales360WriteDAL   : ISales360WriteDAL
    {
        public Sales360WriteDAL()
		{
        }       
    }
}

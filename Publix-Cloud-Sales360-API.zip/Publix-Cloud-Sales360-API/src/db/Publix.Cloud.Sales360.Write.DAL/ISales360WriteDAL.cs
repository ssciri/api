﻿
namespace Publix.Cloud.Sales360.Write.DAL

{
    public interface ISales360WriteDAL
    {
        
    }
}

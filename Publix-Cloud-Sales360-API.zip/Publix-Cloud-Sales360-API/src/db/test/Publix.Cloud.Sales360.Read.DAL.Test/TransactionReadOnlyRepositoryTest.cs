using System;
using Xunit;
using Publix.Cloud.Sales360.DAL.Read;
using Moq;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.Common.Cosmos;
using System.Collections.Generic;
using Publix.Sales360.Models;
using System.Threading.Tasks;
using Publix.Cloud.Sales360.API.Common;
using Microsoft.Azure.Cosmos;

namespace Publix.Cloud.Sales360.API.DAC.Command.Query.Test
{
    public class TransactionReadOnlyRepositoryTest
    {
        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByTransactionIds_With_ValidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[] { "1", "2", "3" };
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "2"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByTransactionIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, transactionIds.Length);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByTransactionIds_With_ValidTransactionIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[] { "1", "1", "3" };
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByTransactionIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }


        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByTransactionIds_With_ValidInvalidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[] { "1", "1", "3" };
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByTransactionIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByTransactionIds_With_NullOrEmptyInput()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[0];
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByTransactionIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByTransactionIds_With_NullInput()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = null;
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByTransactionIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }


        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_ValidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "2", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "2"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, itemIds.Length);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_ValidTransactionIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_StartDate_ValidTransactionIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters
            {
                PhoneNumber = phoneNumber,
                ItemId = itemIds,
                StartDate = DateTime.Parse("2021-02-13")
            }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_EndDate_ValidTransactionIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds, EndDate = DateTime.Parse("2021-02-13") }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_StartDateAndEndDate_ValidTransactionIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds, StartDate = DateTime.Parse("2021-02-13"), EndDate = DateTime.Parse("2021-02-13") }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }


        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_StartDateAndEndDateInvalid_ValidTransactionIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds, StartDate = DateTime.Parse("2021-02-15"), EndDate = DateTime.Parse("2021-02-13") }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }


        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_InvalidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_NullOrEmptyInput()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[0];
            string phoneNumber = "";
            string startDate = "";
            string endDate = "";
            var expectedTransactions = new List<SalesTransaction>();
            var parameters = new Dictionary<string, object>();
            parameters.Add("@PhoneNumber", phoneNumber);

            var query = new QueryInfo
            {
                QueryText = CosmosQueries.GET_TRANSACTIONS_BY_PHONENUMBER_AND_ITEMIDS,
                Parameters = new Dictionary<string, object>() { }
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds, StartDate = null, EndDate = null }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_NullInput()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = null;
            string phoneNumber = null;
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPhoneAndItemIds_With_ValidTransactionIds_ThrowsCosmosException()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "2", "3" };
            string phoneNumber = "test";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "2"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                //.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .ThrowsAsync(new CosmosException("Error", System.Net.HttpStatusCode.TooManyRequests, 0, "123", 0))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act and Assert
            Assert.ThrowsAsync<CosmosException>(async () => await handler.GetTransactionByPhoneAndItemIds(new SearchParameters { PhoneNumber = phoneNumber, ItemId = itemIds }));

        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPartialCard_With_ValidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "2", "3" };
            var storeNum = 1234;
            string firstSix = "123456";
            string lastFour = "1234";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "2"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPartialCard(new SearchParameters { FirstSixCardNo = firstSix, LastFourCardNo = lastFour, StoreId = storeNum, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, itemIds.Length);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public async Task Test_TransactionReadOnlyRepository_GetTransactionByPartialCard_With_EmptyDb()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "1", "3" };
            var storeNum = 1234;
            string firstSix = "123456";
            string lastFour = "1234";
            var expectedTransactions = new List<SalesTransaction>();
            var queryInfo = new QueryInfo() { QueryText = CosmosQueries.GET_TRANSACTIONS_BY_PARTIAL_CARD + CosmosQueries.GET_TRANSACTIONS_ADD_FILTER_ITEMIDS, Parameters = new Dictionary<string, object>() };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = await handler.GetTransactionByPartialCard(new SearchParameters { FirstSixCardNo = firstSix, LastFourCardNo = lastFour, StoreId = storeNum, ItemId = itemIds });

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPartialCard_With_NullOrEmptyInput()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[0];
            var storeNum = 1234;
            string firstSix = "123456";
            string lastFour = "1234";
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPartialCard(new SearchParameters { FirstSixCardNo = firstSix, LastFourCardNo = lastFour, StoreId = storeNum, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPartialCard_With_NullInput()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = null;
            int? storeNum = null;
            string firstSix = null;
            string lastFour = null;
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByPartialCard(new SearchParameters { FirstSixCardNo = firstSix, LastFourCardNo = lastFour, StoreId = storeNum, ItemId = itemIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByPartialCard_With_ValidTransactionIds_ThrowsCosmosException()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] itemIds = new string[] { "1", "2", "3" };
            var storeNum = 1234;
            string firstSix = "123456";
            string lastFour = "1234";
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "2"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                //.Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .ThrowsAsync(new CosmosException("Error", System.Net.HttpStatusCode.TooManyRequests, 0, "123", 0))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act and Assert
            Assert.ThrowsAsync<CosmosException>(async () => await handler.GetTransactionByPartialCard(new SearchParameters { FirstSixCardNo = firstSix, LastFourCardNo = lastFour, StoreId = storeNum, ItemId = itemIds }));
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByReceiptIds_With_ValidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] receiptIds = new string[] { "1", "2", "3" };
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1"},
                new SalesTransaction() { TransactionId = "2"},
                new SalesTransaction() { TransactionId = "3"}
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { ReceiptIds = receiptIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, receiptIds.Length);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_GetTransactionByReceiptIds_With_ValidInvalidTransactionIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] receiptIds = new string[] { "1", "1", "3" };
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { ReceiptIds = receiptIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_With_ValidReceiptIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[] { "1", "2", "3" };
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1", ReceiptDetail = new ReceiptDetail(){ReceiptId = "11"} },
                new SalesTransaction() { TransactionId = "2", ReceiptDetail = new ReceiptDetail(){ReceiptId = "22"} },
                new SalesTransaction() { TransactionId = "3", ReceiptDetail = new ReceiptDetail(){ReceiptId = "33"} }
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, transactionIds.Length);
            Assert.Equal(actualResponse, expectedTransactions);
        }


        [Fact]
        public void Test_TransactionReadOnlyRepository_With_ValidReceiptIds_Duplicate()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[] { "1", "1", "3" };
            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1", ReceiptDetail = new ReceiptDetail(){ReceiptId = "11"} },
                new SalesTransaction() { TransactionId = "3", ReceiptDetail = new ReceiptDetail(){ReceiptId = "33"} }
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, expectedTransactions.Count);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_With_ValidInvalidReceiptIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[] { "1", "1", "3" };
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_With_ValidNullOrEmptyInput_ReceiptIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = new string[0];
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_With_ValidNullInput_ReceiptIds()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] transactionIds = null;
            var expectedTransactions = new List<SalesTransaction>();
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByReceiptIds(new SearchParameters { TransactionIds = transactionIds }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }


        [Fact]
        public void Test_TransactionReadOnlyRepository_With_ValidCustomerIdentifications()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] customerIds = new string[] { "8635956082", "8637013432" };
            Int32? customerIdType = 1;
            int[] customerReasonCode = new int[] { 1 };

            var expectedTransactions = new List<SalesTransaction>() {
                new SalesTransaction(){ TransactionId = "1",
                    CustomerSelfIdentifications = new List<CustomerSelfIdentifications>
                    {
                        new CustomerSelfIdentifications
                        {
                             CustomerId="8635956082"
                        }
                    }
            },
                 new SalesTransaction(){ TransactionId = "2",
                    CustomerSelfIdentifications = new List<CustomerSelfIdentifications>
                    {
                        new CustomerSelfIdentifications
                        {
                             CustomerId="8637013432"
                        }
                    }
            }
            };
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByCustomerIdentifications(new SearchParameters { CustomerId = customerIds, CustomerIdType = customerIdType, CustomerIdCaptureReasonCodes = customerReasonCode }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.NotEmpty(actualResponse);
            Assert.Equal(actualResponse.Count, customerIds.Length);
            Assert.Equal(actualResponse, expectedTransactions);
        }

        [Fact]
        public void Test_TransactionReadOnlyRepository_With_InValidCustomerIdentifications()
        {
            var mockCosmosApi = new Mock<ICosmosAPI>();
            var mockLogger = new Mock<ILogger<TransactionReadOnlyRepository>>();

            string[] customerIds = new string[] { "-1", "-2" };
            Int32? customerIdType = 1;
            int[] customerReasonCode = new int[] { 1 };

            var expectedTransactions = new List<SalesTransaction>();
                
            // Arrange
            mockCosmosApi.Setup(str => str.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()))
                .Returns(Task.FromResult<IList<SalesTransaction>>(expectedTransactions))
                .Verifiable();

            var handler = new TransactionReadOnlyRepository(mockCosmosApi.Object);

            // Act
            var actualResponse = handler.GetTransactionByCustomerIdentifications(new SearchParameters { CustomerId = customerIds, CustomerIdType = customerIdType, CustomerIdCaptureReasonCodes = customerReasonCode }).Result;

            // Assert
            mockCosmosApi.Verify(x => x.GetItemsAsync<SalesTransaction>(It.IsAny<Sales360Context>(), It.IsAny<QueryInfo>()), Times.Once());
            Assert.Empty(actualResponse);
        }
    }
}

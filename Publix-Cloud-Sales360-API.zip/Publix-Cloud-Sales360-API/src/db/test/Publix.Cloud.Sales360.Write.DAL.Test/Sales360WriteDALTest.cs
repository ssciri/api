using System;
using Xunit;
using Moq;
using Publix.Cloud.Sales360.Write.DAL;
using Microsoft.Extensions.Logging;
using Publix.Cloud.Sales360.Common.Cosmos;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.API.DAC.Command.Test
{
    public class Sales360WriteDALTest
    {
        Mock<ICosmosAPI> mocCosmosApi = new Mock<ICosmosAPI>();
        Mock<ILogger<Sales360WriteDAL>> mockLogger = new Mock<ILogger<Sales360WriteDAL>>();
        
        [Fact]
        public async Task CreateSalesTransaction_With_ValidJsonDataAndPatitionKey()
        {
            // Arrange
            mocCosmosApi.Setup(repo => repo.CreateItemAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult<object>((object)null))
                .Verifiable();
            
            var dal = new Sales360WriteDAL(mocCosmosApi.Object, mockLogger.Object);

            // Act
            string testData = "Data = \"{ \"id\":\"123\",\"transactionId\": \"035610120201115110218306-04:00CVA7F37S2VTN5AND\",    \"transactionBusinessDate\": \"2020-11-15\", \"transactionDatetimeLocal\": \"2020-11-15T11:02:18\"}\" ";
            string partitionKey = "035610120201115110218306-04:00CVA7F37S2VTN5AND";
            await dal.CreateSalesTransaction(testData, partitionKey);

            // Assert
            mocCosmosApi.Verify();
        }

        [Fact]
        public async Task CreateSalesTransaction_With_ValidJsonDataAndInValidPatitionKey()
        {
            // Arrange
            mocCosmosApi.Setup(repo => repo.CreateItemAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult<object>((object)null))
                .Verifiable();

            var dal = new Sales360WriteDAL(mocCosmosApi.Object, mockLogger.Object);

            // Act
            string testData = "Data = \"{ \"id\":\"123\",\"transactionId\": \"035610120201115110218306-04:00CVA7F37S2VTN5AND\",    \"transactionBusinessDate\": \"2020-11-15\", \"transactionDatetimeLocal\": \"2020-11-15T11:02:18\"}\" ";
            string partitionKey = "";
            await dal.CreateSalesTransaction(testData, partitionKey);

            // Assert
            mocCosmosApi.Verify();
        }

        [Fact]
        public void CreateSalesTransaction_With_InValidJsonData()
        {
            // Arrange
            mocCosmosApi.Setup(repo => repo.CreateItemAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new Exception());

            var dal = new Sales360WriteDAL(mocCosmosApi.Object, mockLogger.Object);

            // Act
            string testData = "Data = \"transactionId\": \"035610120201115110218306-04:00CVA7F37S2VTN5AND\",    \"transactionBusinessDate\": \"2020-11-15\", \"transactionDatetimeLocal\": \"2020-11-15T11:02:18\"}\" ";
            string partitionKey = "";

            // Assert
            Assert.ThrowsAsync<Exception>(() => dal.CreateSalesTransaction(testData, partitionKey));
            
        }

        [Fact]
        public async Task CreateSalesTransaction_With_NullPartitionKey()
        {
            // Arrange
            mocCosmosApi.Setup(repo => repo.CreateItemAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult<object>((object)null))
                .Verifiable();

            var dal = new Sales360WriteDAL(mocCosmosApi.Object, mockLogger.Object);

            // Act
            string testData = "Data = \"{ \"id\":\"123\",\"transactionId\": \"035610120201115110218306-04:00CVA7F37S2VTN5AND\",    \"transactionBusinessDate\": \"2020-11-15\", \"transactionDatetimeLocal\": \"2020-11-15T11:02:18\"}\" ";
            string partitionKey = null;
            await dal.CreateSalesTransaction(testData, partitionKey);

            // Assert
            mocCosmosApi.Verify();
        }
    }
}

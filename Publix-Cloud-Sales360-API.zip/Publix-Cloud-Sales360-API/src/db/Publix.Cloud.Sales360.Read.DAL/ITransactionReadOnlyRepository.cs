﻿using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Sales360.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.DAL.Read
{
	public interface ITransactionReadOnlyRepository
	{
		Task<IList<SalesTransaction>> GetTransactionByTransactionIds(SearchParameters filter = null);

		Task<SalesTransaction> GetTransactionByTransactionId(string transactionId);

		Task<IList<SalesTransaction>> GetTransactionByPhoneAndItemIds(SearchParameters filter);

		Task<IList<SalesTransaction>> GetTransactionByPartialCard(SearchParameters filter);

		Task<IList<SalesTransaction>> GetTransactionByReceiptIds(SearchParameters filter = null);
		Task<IList<SalesTransaction>> GetTransactionByCustomerIdentifications(SearchParameters filter = null);
		
	}
}

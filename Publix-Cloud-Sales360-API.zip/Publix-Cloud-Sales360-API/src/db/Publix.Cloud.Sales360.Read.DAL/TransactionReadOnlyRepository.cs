﻿using Publix.Cloud.Sales360.Common.Cosmos;
using Publix.Sales360.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Publix.Cloud.Sales360.API.Common;
using System.Text;
using System;

namespace Publix.Cloud.Sales360.DAL.Read
{
    public class TransactionReadOnlyRepository : ITransactionReadOnlyRepository
    {
        private ICosmosAPI _cosmosApi;

        public TransactionReadOnlyRepository(ICosmosAPI cosmosApi)
        {
            _cosmosApi = cosmosApi;
        }

        public async Task<IList<SalesTransaction>> GetTransactionByTransactionIds(SearchParameters filter)
        {
            var query = new CosmosQueryBuilder(CosmosQueries.GET_TRANSACTIONS_BY_IDS)
                .AddParameter("@TransactionIds", filter.TransactionIds)
                .Build();

            var executionContext = new Sales360Context
            {
                OperationName = Sales360Constants.BUSINESS_OPERATION_GET_TRANSACTIONS_BY_TRANSACTION_IDS,
                Params = GetParameterValues(query.Parameters)
            };
            return await _cosmosApi.GetItemsAsync<SalesTransaction>(executionContext, query);
        }


        public async Task<SalesTransaction> GetTransactionByTransactionId(string transactionId)
        {
            var query = new CosmosQueryBuilder(CosmosQueries.GET_TRANSACTION_BY_ID)
                .AddParameter("@TransactionId", transactionId)
                .Build();

            var executionContext = new Sales360Context
            {
                OperationName = Sales360Constants.BUSINESS_OPERATION_GET_TRANSACTION_BY_TRANSACTION_ID,
                Params = GetParameterValues(query.Parameters)
            };
            var result = await _cosmosApi.GetItemsAsync<SalesTransaction>(executionContext, query);
            return result.FirstOrDefault();
        }


        public async Task<IList<SalesTransaction>> GetTransactionByPhoneAndItemIds(SearchParameters filter)
        {
            var query = new CosmosQueryBuilder(CosmosQueries.GET_TRANSACTIONS_BY_PHONENUMBER_AND_ITEMIDS)
                .AddParameter("@PhoneNumber", filter.PhoneNumber)
                .AddItemIdFilter(filter.ItemId)
                .AddDateRangeFilter(filter.StartDate, filter.EndDate).Build();

            var executionContext = new Sales360Context
            {
                OperationName = Sales360Constants.BUSINESS_OPERATION_GET_TRANSACTIONS_BY_PHONENUMBER,
                Params = GetParameterValues(query.Parameters)
            };
            return await _cosmosApi.GetItemsAsync<SalesTransaction>(executionContext, query);
        }

        private static string GetParameterValues(Dictionary<string, object> fields)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in fields)
            {
                var value = item.Value == null ? "" : item.Value;
                Type valueType = value.GetType();
                var expectedType = typeof(string);
                if (value != null && valueType.IsArray && expectedType.IsAssignableFrom(valueType.GetElementType()))
                {
                    value = string.Join(",", (string[])item.Value);
                }
                sb.Append(item.Key).Append(":").Append(value).Append("|");
            }
            return sb.ToString();
        }

        public async Task<IList<SalesTransaction>> GetTransactionByPartialCard(SearchParameters filter)
        {
            var query = new CosmosQueryBuilder(CosmosQueries.GET_TRANSACTIONS_BY_PARTIAL_CARD)
                .AddParameter("@firstsixcardno", filter.FirstSixCardNo)
                .AddParameter("@lastfourcardno", filter.LastFourCardNo)
                .AddParameter("@storeid", filter.StoreId)
                .AddItemIdFilter(filter.ItemId)
                .AddDateRangeFilter(filter.StartDate, filter.EndDate).Build();

            var executionContext = new Sales360Context
            {
                OperationName = Sales360Constants.BUSINESS_OPERATION_GET_TRANSACTIONS_BY_PARTIAL_CARDNUMBER,
                Params = GetParameterValues(query.Parameters)
            };
            return await _cosmosApi.GetItemsAsync<SalesTransaction>(executionContext, query);
        }

        public async Task<IList<SalesTransaction>> GetTransactionByReceiptIds(SearchParameters filter)
        {
            var query = new CosmosQueryBuilder(CosmosQueries.GET_TRANSACTIONS_BY_RECEIPTIDS)
                .AddParameter("@ReceiptIds", filter.ReceiptIds)
                .Build();

            var executionContext = new Sales360Context
            {
                OperationName = Sales360Constants.BUSINESS_OPERATION_GET_TRANSACTION_BY_RECEIPT_IDS,
                Params = GetParameterValues(query.Parameters)
            };
            return await _cosmosApi.GetItemsAsync<SalesTransaction>(executionContext, query);
        }
        public async Task<IList<SalesTransaction>> GetTransactionByCustomerIdentifications(SearchParameters filter)
        {
            var query = new CosmosQueryBuilder(CosmosQueries.GET_TRANSACTIONS_BY_CUSTOMERIDENTIFICATIONS)
                .AddParameter("@CustomerIds", filter.CustomerId)
                .AddParameter("@CustomerIdType", filter.CustomerIdType)
                .AddCustomerReasonCodeFilter(filter.CustomerIdCaptureReasonCodes)
                .AddDateRangeFilter(filter.StartDate, filter.EndDate).Build();

            var executionContext = new Sales360Context
            {
                OperationName = Sales360Constants.BUSINESS_OPERATION_GET_TRANSACTION_BY_CUSTOMER_IDENTIFICATIONS,
                Params = GetParameterValues(query.Parameters)
            };
            return await _cosmosApi.GetItemsAsync<SalesTransaction>(executionContext, query);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Publix.Sales360.Models
{
	[JsonObject(MemberSerialization.OptIn)]
	public class SalesTransaction
	{
		[JsonProperty("id")]
		public string Id { get; set; }
		
		[JsonProperty]
		public string TransactionId { get; set; }
		[JsonProperty]
		public string SchemaVersion { get; set; }
		[JsonProperty]
		public string EventId { get; set; }
		[JsonProperty]
		public string EventType { get; set; }
		[JsonProperty]
		public string TransactionBusinessDate { get; set; }
		[JsonProperty]
		public string TransactionDatetimeLocal { get; set; }
		[JsonProperty]
		public string TransactionDatetimeUtc { get; set; }
		[JsonProperty]
		public bool IsTransactionVoidFlag { get; set; }
		[JsonProperty]
		public bool IsTransactionSavedFlag { get; set; }
		[JsonProperty]
		public bool IsTransactionTrainingFlag { get; set; }
		[JsonProperty]
		public bool IsSyntheticFlag { get; set; }
		[JsonProperty]
		public Int32 SourceSystemId { get; set; }
		[JsonProperty]
		public TransactionSummary TransactionSummary { get; set; }
		[JsonProperty]
		public List<CustomerSelfIdentifications> CustomerSelfIdentifications { get; set; }
		[JsonProperty]
		public ReceiptDetail ReceiptDetail { get; set; }
		[JsonProperty]
		public List<LineItems> LineItems { get; set; }		
		[JsonProperty]
		public List<Tenders> Tenders { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class TransactionSummary
	{
		[JsonProperty]
		public string TransactionType { get; set; }
		[JsonProperty]
		public Int32 FulfillmentStoreId { get; set; }
		[JsonProperty]
		public Int32 LaneId { get; set; }
		[JsonProperty]
		public string CashierId { get; set; }
		[JsonProperty]
		public string ExternalOrderId { get; set; }
		[JsonProperty]
		public string InternalOrderId { get; set; }
		[JsonProperty]
		public Int32 RingElapsedTime { get; set; }
		[JsonProperty]
		public Int32 TenderElapsedTime { get; set; }
		[JsonProperty]
		public Int32 IdleElapsedTime { get; set; }
		[JsonProperty]
		public Int32 LockElapsedTime { get; set; }
		[JsonProperty]
		public string FulfillmentDatetimeLocal { get; set; }
		[JsonProperty]
		public string FulfillmentDatetimeUtc { get; set; }
		[JsonProperty]
		public string TotalPreTaxAmount { get; set; }
		[JsonProperty]
		public string TotalTaxAmount { get; set; }
		[JsonProperty]
		public string TotalAmount { get; set; }
		[JsonProperty]
		public Int32? RefundSystemId { get; set; }
		[JsonProperty]
		public List<Sources> Sources { get; set; }

		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class Sources
	{
		[JsonProperty]
		public string Source { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class CustomerSelfIdentifications
	{
		[JsonProperty]
		public string CustomerId { get; set; }
		[JsonProperty]
		public Int32? CustomerIdType { get; set; }
		[JsonProperty]
		public Int32? CustomerIdCaptureReasonCode { get; set; }
		[JsonProperty]
		public Int32 CustomerIdEntryMode { get; set; }
		[JsonProperty]
		public bool IsUsedForDigitalPromotionsFlag { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ReceiptDetail
	{
		[JsonProperty]
		public string ReceiptId { get; set; }
		[JsonProperty]
		public string ReceiptHeaderSection1 { get; set; }
		[JsonProperty]
		public string ReceiptHeaderSection2 { get; set; }
		[JsonProperty]
		public string ReceiptHeaderSection3 { get; set; }
		[JsonProperty]
		public string ReceiptHeaderSection4 { get; set; }
		[JsonProperty]
		public string ReceiptHeaderSection5 { get; set; }
		[JsonProperty]
		public string ReceiptHeaderSection6 { get; set; }
		[JsonProperty]
		public string ReceiptFooterSection1 { get; set; }
		[JsonProperty]
		public string ReceiptFooterSection2 { get; set; }
		[JsonProperty]
		public string ReceiptFooterSection3 { get; set; }
		[JsonProperty]
		public string ReceiptFooterSection4 { get; set; }
		[JsonProperty]
		public string ReceiptFooterSection5 { get; set; }
		[JsonProperty]
		public string ReceiptFooterSection6 { get; set; }

	}
	[JsonObject(MemberSerialization.OptIn)]
	public class LineItems
	{
		[JsonProperty]
		public string LineItemCategory { get; set; }
		[JsonProperty]
		public string ItemId { get; set; }
		[JsonProperty]
		public string ItemSku { get; set; }
		[JsonProperty]
		public string ItemDescription { get; set; }
		[JsonProperty]
		public Int32 ItemSubdepartmentId { get; set; }
		[JsonProperty]
		public string ItemUom { get; set; }
		[JsonProperty]
		public string ItemUnitPrice { get; set; }
		[JsonProperty]
		public Int32 ItemMsu { get; set; }
		[JsonProperty]
		public string ItemPrice { get; set; }
		[JsonProperty]
		public bool IsPriceManuallyEnteredFlag { get; set; }
		[JsonProperty]
		public bool IsManualPriceEntryAllowedFlag { get; set; }
		[JsonProperty]
		public string ItemQuantity { get; set; }
		[JsonProperty]
		public string ItemWeight { get; set; }
		[JsonProperty]
		public string ItemTransactionType { get; set; }
		[JsonProperty]
		public string ItemLocateMode { get; set; }
		[JsonProperty]
		public bool IsItemVoidFlag { get; set; }
		[JsonProperty]
		public bool IsItemPrescriptionFlag { get; set; }
		[JsonProperty]
		public bool IsItemCouponAppliedFlag { get; set; }
		[JsonProperty]
		public bool IsItemRestrictedFlag { get; set; }
		[JsonProperty]
		public bool IsItemFoodStampsAllowedFlag { get; set; }
		[JsonProperty]
		public bool IsItemNonMerchandiseFlag { get; set; }
		[JsonProperty]
		public bool IsItemTaxExemptedFlag { get; set; }
		[JsonProperty]
		public string ItemNonPromoPrice { get; set; }
		[JsonProperty]
		public Int32 ItemSequenceNo { get; set; }
		[JsonProperty]
		public List<ItemTaxes> ItemTaxes { get; set; }
		[JsonProperty]
		public ItemTare ItemTare { get; set; }
		[JsonProperty]
		public ItemPriceOverride ItemPriceOverride { get; set; }
		[JsonProperty]
		public List<RedeemedRainchecks> RedeemedRainchecks { get; set; }
		[JsonProperty]
		public List<ItemPromotions> ItemPromotions { get; set; }
		[JsonProperty]
		public List<ItemPurchases> ItemPurchases { get; set; }
		[JsonProperty]
		public List<ItemRefunds> ItemRefunds { get; set; }
		[JsonProperty]
		public List<string> ItemRefundPrices { get; set; }
		[JsonProperty]
		public ItemGiftcard ItemGiftcard { get; set; }
		[JsonProperty]
		public ItemPackage ItemPackage { get; set; }
		[JsonProperty]
		public ItemRx ItemRx { get; set; }

		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemTaxes 
	{
		[JsonProperty]
		public Int32 ItemTaxPlanId { get; set; }
		[JsonProperty]
		public string ItemTaxAmount { get; set; }
		[JsonProperty]
		public string ItemTaxDiscountAmount { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemTare 
	{
		[JsonProperty]
		public string ItemWeight { get; set; }
		[JsonProperty]
		public string TareWeight { get; set; }
		[JsonProperty]
		public bool IsTareWeightManualFlag { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemPriceOverride 
	{
		[JsonProperty]
		public string ItemPriceOriginal { get; set; }
		[JsonProperty]
		public string ItemPriceNew { get; set; }
		[JsonProperty]
		public string ItemMsuOriginal { get; set; }
		[JsonProperty]
		public string ItemMsuNew { get; set; }
		[JsonProperty]
		public string ItemPriceOverrideReasoncode { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class RedeemedRainchecks 
	{
		[JsonProperty]
		public string RaincheckId { get; set; }
		[JsonProperty]
		public string ItemPriceOriginal { get; set; }
		[JsonProperty]
		public string ItemPriceNew { get; set; }
		[JsonProperty]
		public string ItemMsuOriginal { get; set; }
		[JsonProperty]
		public string ItemMsuNew { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemPromotions 
	{
		[JsonProperty]
		public Int32 MixMatchId { get; set; }
		[JsonProperty]
		public long PromotionId { get; set; }
		[JsonProperty]
		public string PriceMethod { get; set; }
		[JsonProperty]
		public Int32 RewardType { get; set; }
		[JsonProperty]
		public string DealPrice { get; set; }
		[JsonProperty]
		public Int32 DealQuantity { get; set; }
		[JsonProperty]
		public string ItemDiscountAmount { get; set; }
		[JsonProperty]
		public Int32 AvailPromoMixMatchId { get; set; }
		[JsonProperty]
		public string AvailPromoMSU { get; set; }
		[JsonProperty]
		public string AvailPromotionId { get; set; }
		[JsonProperty]
		public string AvailPromoPriceMethod { get; set; }
		[JsonProperty]
		public string AvailPromoRewardType { get; set; }
		[JsonProperty]
		public Int32 AvailPromoThresholdQty { get; set; }
		[JsonProperty]
		public bool IsPromotionApplied { get; set; }
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemPurchases 
	{
		[JsonProperty]
		public string PurchaseTransactionId { get; set; }
		[JsonProperty]
		public Int32 PurchaseItemSequenceNo { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemRefunds 
	{
		[JsonProperty]
		public string RefundTransactionId { get; set; }
		[JsonProperty]
		public Int32 RefundItemSequenceNo { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemGiftcard 
	{
		[JsonProperty]
		public string GiftcardNumberActivated { get; set; }
		[JsonProperty]
		public string GiftcardAuthorizationId { get; set; }
		[JsonProperty]
		public string GiftcardReferenceId { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemPackage
	{
		[JsonProperty]
		public string PackageWeight { get; set; }
		[JsonProperty]
		public string PackageExtendedPrice { get; set; }
		[JsonProperty]
		public Int32 PackageQuantity { get; set; }
		[JsonProperty]
		public string PackagePackagingDate { get; set; }
		[JsonProperty]
		public string PackageSellByDate { get; set; }
		[JsonProperty]
		public string PackageExpiryDate { get; set; }
		[JsonProperty]
		public string PackageProductionDate { get; set; }
		[JsonProperty]
		public long PackageBatchLotNumber { get; set; }
		[JsonProperty]
		public long PackageSerialNumber { get; set; }
		[JsonProperty]
		public string PackageCountryOfOrigin { get; set; }
		[JsonProperty]
		public List<ItemPackageItems> ItemPackageItems { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemPackageItems 
	{
		[JsonProperty]
		public string PackageItemId { get; set; }
		[JsonProperty]
		public string PackageItemWeight { get; set; }
		[JsonProperty]
		public string PackageItemExpiryDate { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class ItemRx 
	{
		[JsonProperty]
		public string RxNumber { get; set; }
		[JsonProperty]
		public string RxFill { get; set; }
		[JsonProperty]
		public string RxPartialFill { get; set; }
		
	}		
	[JsonObject(MemberSerialization.OptIn)]
	public class Tenders 
	{
		[JsonProperty]
		public Int32 TenderType { get; set; }
		[JsonProperty]
		public string TenderAmount { get; set; }
		[JsonProperty]
		public string TenderFee { get; set; }
		[JsonProperty]
		public bool IsTenderIsChangeFlag { get; set; }
		[JsonProperty]
		public bool IsTenderVoidFlag { get; set; }
		[JsonProperty]
		public bool IsTenderRefundFlag { get; set; }
		[JsonProperty]
		public TenderEft TenderEft { get; set; }
		[JsonProperty]
		public TenderEwic TenderEwic { get; set; }

		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class TenderEft 
	{
		[JsonProperty]
		public string EftToken { get; set; }
		[JsonProperty]
		public string EftCardType { get; set; }
		[JsonProperty]
		public string EftAccountNumber { get; set; }
		[JsonProperty]
		public string EftAccountNumberFirstSix { get; set; }
		[JsonProperty]
		public string EftAccountNumberLastFour { get; set; }
		[JsonProperty]
		public bool IsEftTenderFsaFlag { get; set; }
		[JsonProperty]
		public string EftPaymentAccountReference { get; set; }
		[JsonProperty]
		public string EftTraceId { get; set; }
		[JsonProperty]
		public string EftAuthorizationId { get; set; }
		[JsonProperty]
		public string EftReferenceId { get; set; }
		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class TenderEwic
	{
		[JsonProperty]
		public string EWicState { get; set; }
		[JsonProperty]
		public List<EWicItems> EWicItems { get; set; }

		
	}
	[JsonObject(MemberSerialization.OptIn)]
	public class EWicItems 
	{
		[JsonProperty]
		public string EWicItemUpc { get; set; }
		[JsonProperty]
		public Int32 EWicItemCategory { get; set; }
		[JsonProperty]
		public Int32 EWicItemSubCategory { get; set; }
		[JsonProperty]
		public string EWicItemPrice { get; set; }
		[JsonProperty]
		public string EWicItemApprovedPrice { get; set; }
		[JsonProperty]
		public string EWicItemCount { get; set; }
		[JsonProperty]
		public bool IsEWicItemPluIndicator { get; set; }
		
	}
}

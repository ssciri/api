using System.Threading.Tasks;
using Xunit;
using Moq;
using Microsoft.Azure.Cosmos;
using Publix.Sales360.Models;
using Publix.Cloud.Sales360.Common.Cosmos;
using System.Collections.Generic;
using System.Threading;
using Publix.Cloud.Sales360.API.Common;
using Microsoft.Extensions.Logging;

namespace Publix.Cloud.Sales360.Common.Test
{
	public class CosmosApiTest
	{
		[Fact]
        public void Should_GetItemsAsync_When_Query_NotNull()
        {
            //Arrange
            var expectedTransactions = new List<SalesTransaction>
            {
                new SalesTransaction(),
                new SalesTransaction()
            };

            var feedResponseMock = new Mock<FeedResponse<SalesTransaction>>();
            feedResponseMock.Setup(x => x.GetEnumerator()).Returns(expectedTransactions.GetEnumerator());
            

            var feedIteratorMock = new Mock<FeedIterator<SalesTransaction>>();
            feedIteratorMock.Setup(f => f.HasMoreResults).Returns(true);
            feedIteratorMock
                .Setup(f => f.ReadNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(feedResponseMock.Object)
                .Callback(() => feedIteratorMock
                    .Setup(f => f.HasMoreResults)
                    .Returns(false))
                .Verifiable();

            var loggerMock = new Mock<ILogger<CosmosAPI>>();
            var containerMock = new Mock<Container>();
            containerMock
                .Setup(c => c.GetItemQueryIterator<SalesTransaction>(
                    It.IsAny<QueryDefinition>(),
                    It.IsAny<string>(),
                    It.IsAny<QueryRequestOptions>()))
                .Returns(feedIteratorMock.Object)
                .Verifiable();

            var subject = new CosmosAPI(containerMock.Object, loggerMock.Object);

            //Act
            var response = subject.GetItemsAsync<SalesTransaction>(new Sales360Context(), new QueryInfo() { QueryText = "select"}).Result;

            //Assert
            Assert.Equal(expectedTransactions, response);
            containerMock.Verify();
        }
    }
}

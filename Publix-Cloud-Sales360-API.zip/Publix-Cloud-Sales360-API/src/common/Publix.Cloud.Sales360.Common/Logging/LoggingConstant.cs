﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.Common.Logging
{

    /// <summary>
    /// Contains constants and enums for consistent structured logging
    /// </summary>
    public static class LoggingConstants
    {
        // Template for consisted structured logging accross multiple functions, each field is described below: 
        // EventDescription is a short description of the Event being logged. 
        // EntityId: Id of the Business Entity being processed: e.g. TransactionId, etc. 
        // EventID: Unique identifier of the message that can be processed by more than one component. 
        public const string Template = "{EventDescription}, {EventId}, {OperationContext}, {EventCode}, {EventDuration},{EntityId}";
        public const string CosmosTemplate = "{EventDescription}, {EventId}, {OperationContext}, {EventCode}, {EntityId}, {EventCharge}, {EventDuration}, {CosmosActivityId}";
        
        /// <summary>
        /// Enumeration of all different EventId that can be used for logging
        /// </summary>
        public enum EventCode
        {
            GetItems = 1000,
            SearchByPhoneNumberAndItemIdFailed = 1101,
            SearchByPhoneNumberAndItemIdSucceeded = 1001,

            SearchByTransactionIdsFailed = 1102,
            SearchByTransactionIdsSucceeded = 1002,

            SearchByPartialCardFailed = 1103,
            SearchByPartialCardSucceeded = 1003,

            GetSalesTransactionSucceeded = 1008,
            GetSalesTransactionFailed = 1108,

            ProcessingFailedInvalidData = 1201,
            ProcessingFailedUnhandledException = 1202,

            CosmosRequestCharge = 1206
        }

        public enum OperationName
        {
            SearchSalesTransactionByPhoneNumberAndItemId,
            SeachSalesTransactionByPartialCard,
            SearchSalesTransactionByQueries,
            SearchSalesTransactionByTransactionIds,
            SearchSalesTransactionByReceiptIds,
            SearchTransactionByCustomerIdentifications
        }


    }
}


﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.Common.Cosmos
{
    public static class CosmosQueries
    {
        public static string GET_TRANSACTION_BY_ID => "SELECT* FROM c WHERE c.transactionId = @TransactionId";
        public static string GET_TRANSACTIONS_BY_IDS => "SELECT * FROM c WHERE ARRAY_CONTAINS(@TransactionIds, c.transactionId)";
        public static string GET_TRANSACTIONS_BY_PHONENUMBER_AND_ITEMIDS => "SELECT distinct VALUE c FROM c " +
            "join e in c.customerSelfIdentifications " +
            "join d in c.lineItems WHERE Array_Length(c.customerSelfIdentifications) > 0 " +
            "and e.customerIdType = 1 " +
            "and e.customerId = @PhoneNumber ";

        public static string GET_TRANSACTIONS_ADD_FILTER_ITEMIDS => " and ARRAY_CONTAINS(@ItemIds, d.itemId)";

        public static string GET_TRANSACTIONS_ADD_FILTER_EXACT_DATE => " and c.transactionBusinessDate = @BusinessDate ";

        public static string GET_TRANSACTIONS_ADD_FILTER_DATE_RANGE => " and c.transactionBusinessDate >= @StartDate and c.transactionBusinessDate <= @EndDate ";
        public static string GET_TRANSACTIONS_BY_PARTIAL_CARD => "SELECT distinct VALUE c FROM c " +
            "join d in c.lineItems " +
            "join e in c.tenders  " +
            "where e.tenderEft.eftAccountNumberFirstSix = @firstsixcardno " +
            "and e.tenderEft.eftAccountNumberLastFour = @lastfourcardno " +
            "and c.transactionSummary.fulfillmentStoreId  = @storeid ";
        public static string GET_TRANSACTIONS_BY_RECEIPTIDS => "SELECT * FROM c WHERE ARRAY_CONTAINS(@ReceiptIds, c.receiptDetail.receiptId)";
        public static string GET_TRANSACTIONS_BY_CUSTOMERIDENTIFICATIONS => "SELECT distinct VALUE c From c " +
            "join e in c.customerSelfIdentifications WHERE Array_Length(c.customerSelfIdentifications) > 0  " +
            "and ARRAY_CONTAINS(@CustomerIds, e.customerId) and e.customerIdType = @CustomerIdType ";

        public static string GET_TRANSACTIONS_ADD_FILTER_CUSTOMER_REASON_CODE => " and ARRAY_CONTAINS(@customerReasonCodes,e.customerIdCaptureReasonCode) ";
        public static string GET_TRANSACTIONS_ADD_FILTER_INCLUDE_ALL_CUSTOMER_REASON_CODE => " and e.customerIdCaptureReasonCode !=null and e.customerIdCaptureReasonCode!=0 ";
    }
}

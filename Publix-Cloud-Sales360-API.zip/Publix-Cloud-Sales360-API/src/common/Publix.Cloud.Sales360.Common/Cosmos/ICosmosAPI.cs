﻿using Publix.Cloud.Sales360.API.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.Common.Cosmos
{
    public interface ICosmosAPI
    {
        Task<IList<T>> GetItemsAsync<T>(Sales360Context context, QueryInfo query);
    }
}

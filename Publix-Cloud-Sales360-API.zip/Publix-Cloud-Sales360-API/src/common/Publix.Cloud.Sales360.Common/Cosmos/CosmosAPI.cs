﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Publix.Cloud.Sales360.API.Common;
using Publix.Cloud.Sales360.Common.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

[assembly: InternalsVisibleTo("Publix.Cloud.Sales360.Common.Test")]
namespace Publix.Cloud.Sales360.Common.Cosmos

{
    public class CosmosAPI : ICosmosAPI
    {
        private CosmosClient _cosmosClient;
        private string _databaseName;
		private Container _container;
		private ILogger<CosmosAPI> _logger;

		public CosmosAPI(IConfiguration config, ILogger<CosmosAPI> logger)
        {
			_logger = logger;	
            string connectionString = config.GetConnectionString(Sales360Constants.APPSETTING_COSMOS_CONNECTIONSTRING);
            
            _databaseName = config.GetValue<string>(Sales360Constants.APPSETTING_COSMOS_SALES_TRANSACTION_DATABASE_NAME);
			string containerName = config.GetValue<string>(Sales360Constants.APPSETTING_COSMOS_SALES_TRANSACTION_CONTAINER_NAME);

			int maxRetryAttempts = config.GetValue<int>(Sales360Constants.APPSETTING_COSMOS_RETRY_MAX_ATTEMPTS);
            int maxRetryWaitTime = config.GetValue<int>(Sales360Constants.APPSETTING_COSMOS_RETRY_MAX_WAIT_TIMES);

			HttpClient.DefaultProxy.Credentials = CredentialCache.DefaultCredentials;

			_cosmosClient = new CosmosClient(connectionString,
				new CosmosClientOptions
				{
					MaxRetryAttemptsOnRateLimitedRequests = maxRetryAttempts,
					MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(maxRetryWaitTime)
				}) ;

			_container = _cosmosClient.GetContainer(_databaseName, containerName);
		}

		internal CosmosAPI(Container container,ILogger<CosmosAPI> logger)
		{
			_container = container;
			_logger = logger;
		}

		public async Task<IList<T>> GetItemsAsync<T>(Sales360Context context, QueryInfo query)
		{
			_logger.LogInformation(LoggingConstants.Template,
									"CosmosAPI: GetItemsAsync Begin",
									context.EventId,
									context.OperationName,
									LoggingConstants.EventCode.GetItems,
									0,
									context.Params
									);

			List<T> results = new List<T>();
			
			var queryDefinition = BuildQueryDefinition(query.QueryText, query.Parameters);

			using (FeedIterator<T> resultSet = _container.GetItemQueryIterator<T>(
				queryDefinition: queryDefinition))
			{
				while (resultSet.HasMoreResults)
				{
					FeedResponse<T> response = await resultSet.ReadNextAsync();
					double totalms = 0;
					if(response.Diagnostics != null)
					{
						var timeSpan = response.Diagnostics.GetClientElapsedTime();
						if (timeSpan != null)
							totalms = timeSpan.TotalMilliseconds;
					}
					_logger.LogInformation(LoggingConstants.CosmosTemplate,
									"CosmosAPI: GetItemsAsync",
									context.EventId,
									context.OperationName,
									LoggingConstants.EventCode.GetItems,
									context.Params,
									response.RequestCharge,
									totalms,
									response.ActivityId
									);
					results.AddRange(response);
				}
			}
			return results;
		}

		private static QueryDefinition BuildQueryDefinition(string query, IDictionary<string, object> parameters)
		{
			var queryDefinition = new QueryDefinition(query);
			if (parameters != null)
			{
				foreach (KeyValuePair<string, object> entry in parameters)
				{
					queryDefinition.WithParameter(entry.Key, entry.Value);
				}
			}
			return queryDefinition;
		}
	}
}

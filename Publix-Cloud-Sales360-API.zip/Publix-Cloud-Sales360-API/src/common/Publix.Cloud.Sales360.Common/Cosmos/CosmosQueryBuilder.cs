﻿using Publix.Cloud.Sales360.API.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Publix.Cloud.Sales360.Common.Cosmos
{
    public class CosmosQueryBuilder
    {
        private StringBuilder _query;
        public Dictionary<string, object> fields;

        public CosmosQueryBuilder(string initialQuery)
        {
            this._query = new StringBuilder(initialQuery);
            this.fields = new Dictionary<string, object>();
        }

        public CosmosQueryBuilder AddItemIdFilter(string[] itemIds)
        {
            if (itemIds != null && itemIds.Length > 0)
            {
                fields.Add("@ItemIds", itemIds);
                _query.Append(CosmosQueries.GET_TRANSACTIONS_ADD_FILTER_ITEMIDS);
            }
            return this;
        }

        public CosmosQueryBuilder AddCustomerReasonCodeFilter(int[] customerReasonCodes)
        {
            if (customerReasonCodes != null && customerReasonCodes.Length > 0)
            {
                if (customerReasonCodes.Contains(Sales360Constants.INCLUDE_ALL_CUSTOMER_CAPTURE_REASON_CODE))
                {
                    fields.Add("@customerReasonCodes", customerReasonCodes);
                    _query.Append(CosmosQueries.GET_TRANSACTIONS_ADD_FILTER_INCLUDE_ALL_CUSTOMER_REASON_CODE);
                }
                else
                {
                    fields.Add("@customerReasonCodes", customerReasonCodes);
                    _query.Append(CosmosQueries.GET_TRANSACTIONS_ADD_FILTER_CUSTOMER_REASON_CODE);
                }

            }
            return this;
        }

        public CosmosQueryBuilder AddDateRangeFilter(DateTime? startDate, DateTime? endDate)
        {
            if (startDate.HasValue && endDate.HasValue)
            {
                if (startDate == endDate)
                {
                    fields.Add("@BusinessDate", startDate.Value.ToString("yyyy-MM-dd"));
                    _query.Append(CosmosQueries.GET_TRANSACTIONS_ADD_FILTER_EXACT_DATE);
                }
                else
                {
                    fields.Add("@StartDate", startDate.Value.ToString("yyyy-MM-dd"));
                    fields.Add("@EndDate", endDate.Value.ToString("yyyy-MM-dd"));
                    _query.Append(CosmosQueries.GET_TRANSACTIONS_ADD_FILTER_DATE_RANGE);
                }
            }
            return this;
        }

        public QueryInfo Build()
        {
            return new QueryInfo() { QueryText = _query.ToString(), Parameters = fields };
        }

        public CosmosQueryBuilder AddParameter(string paramName, string paramValue)
        {
            fields.Add(paramName, paramValue);
            return this;
        }

        public CosmosQueryBuilder AddParameter(string paramName, int? paramValue)
        {
            fields.Add(paramName, paramValue);
            return this;
        }

        public CosmosQueryBuilder AddParameter(string paramName, string[] paramValue)
        {
            fields.Add(paramName, paramValue);
            return this;
        }
    }

    public class QueryInfo
    {
        public string QueryText { get; set; }
        public Dictionary<string, object> Parameters { get; set; }
    }

    public class SearchParameters
    {
        public string[] ItemId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string FirstSixCardNo { get; set; }
        public string LastFourCardNo { get; set; }
        public int? StoreId { get; set; }
        public string[] TransactionIds { get; set; }
        public string PhoneNumber { get; set; }
        public string[] ReceiptIds { get; set; }
        public string[] CustomerId { get; set; }
        public Int32? CustomerIdType { get; set; }
        public int[] CustomerIdCaptureReasonCodes { get; set; }
    }
}

﻿

namespace Publix.Cloud.Sales360.API.Common
{
    public static class Sales360Constants
    {
        public const string APPSETTING_COSMOS_CONNECTIONSTRING = "SalesCosmosConnectionString";

        public const string APPSETTING_COSMOS_SALES_TRANSACTION_CONTAINER_NAME = "Cosmos_SalesTransaction_Container_ID";

        public const string APPSETTING_COSMOS_SALES_TRANSACTION_DATABASE_NAME = "Cosmos_SalesTransaction_Database_ID";

        public static string APPSETTING_COSMOS_RETRY_MAX_ATTEMPTS = "CosmosClient_Retry_MaxAttempts";
        public static string APPSETTING_COSMOS_RETRY_MAX_WAIT_TIMES = "CosmosClient_Retry_MaxWaitTime";

        public const string ERROR_MESSAGE_ITEM_NOT_FOUND = "NotFound";
        public const string ERROR_MESSAGE_ITEM_NOT_FOUND_STATUS_CODE = "421";

        public const string APPSETTING_APP_REGISTRATION_SECTION_NAME = "Sales360AppRegistration";
        public const string APPSETTING_APP_REGISTRATION_VALD_AUDIENCES = "Sales360AppRegistration:ValidAudiences";
        public const string APPSETTING_APP_REGISTRATION_VALD_ISSUERS = "Sales360AppRegistration:ValidIssuers";

        public const string APPSETTING_APP_REGISTRATION_ENABLE_DIAGNOSTICS = "Sales360AppRegistration:EnableDiagnostics";

        public const string APPSETTING_APP_REGISTRATION_LOG_LEVEL = "Sales360AppRegistration:LogLevel";

        public static string BUSINESS_OPERATION_GET_TRANSACTION_BY_TRANSACTION_ID = "GetSalesTransactionsByTransactionIds";
        public static string BUSINESS_OPERATION_GET_TRANSACTIONS_BY_TRANSACTION_IDS = "GetSalesTransactionByTransactionId";
        public static string BUSINESS_OPERATION_GET_TRANSACTIONS_BY_PHONENUMBER = "GetSalesTransactionByPhoneNumber";
        public static string BUSINESS_OPERATION_GET_TRANSACTIONS_BY_PARTIAL_CARDNUMBER = "GetSalesTransactionByPartialCardNumber";
        public static string BUSINESS_OPERATION_GET_TRANSACTION_BY_RECEIPT_IDS = "GetSalesTransactionsByReceiptIds";
        public static string BUSINESS_OPERATION_GET_TRANSACTION_BY_CUSTOMER_IDENTIFICATIONS = "GetTransactionByCustomerIdentifications";
        public const int INCLUDE_ALL_CUSTOMER_CAPTURE_REASON_CODE = -1;
    }
}

﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.CSharp;
using Publix.Sales360.Models;

namespace Publix.Cloud.Sales360.API.Common
{
	public class Sales360Context
	{
		public string EventId { get; set; }
		public string OperationName { get; set; }
		public string Params { get; set; }
		
	}
}

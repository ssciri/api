using Azure.Storage.Queues.Models;
using Newtonsoft.Json;
using Publix.Cloud.Sales360.API.E2E.Test.Common;
using Publix.Cloud.Sales360.API.E2E.Test.Models;
using Publix.Cloud.Sales360.API.E2E.Test.Utility;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Publix.Cloud.Sales360.API.E2E.Test
{

    public class Search_E2ETest : IClassFixture<AzureTestFixture>
    {

        private readonly AzureTestFixture _testFixture;


        public Search_E2ETest(AzureTestFixture testFixture)
        {
            _testFixture = testFixture;
        }


        #region Search Valid Test(s)
        [Fact]
        public async Task Search_E2ETest_Scenario_3261()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c=>(string)c.transactionId).ToArray();
            SalesTransactionSearch data = new SalesTransactionSearch { SearchRequestId = scenario.Id, 
                TransactionIds = transactionIds
            };
            var result = _testFixture.SearchTransactions(data).Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);
            
            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.NotEmpty(searchResponse.Transactions);
            Assert.Equal(scenario.TestTransactions.Count, searchResponse.Transactions.Count);
            //Assert.True(TestHelper.JsonCompare(searchResponse.Transactions[0].Data, scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
            Assert.True(TestHelper.JsonCompare(searchResponse.Transactions[1].Data, scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_version1()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearch data = new SalesTransactionSearch
            {
                SearchRequestId = scenario.Id,
                TransactionIds = transactionIds
            };
            var result = _testFixture.SearchTransactions(data, "1.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.NotEmpty(searchResponse.Transactions);
            Assert.Equal(scenario.TestTransactions.Count, searchResponse.Transactions.Count);
            //Assert.True(TestHelper.JsonCompare(searchResponse.Transactions[0].Data, scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
            Assert.True(TestHelper.JsonCompare(searchResponse.Transactions[1].Data, scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }


        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_TransactionId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries= new string[] { "TransactionId"},
                Data = new SearchData()
				{
                    TransactionId = transactionIds
				}
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Equal(scenario.TestTransactions.Count, searchResponse.TransactionsByTransactionIdQueryResponse.Data.Count);
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByTransactionIdQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByTransactionIdQueryResponse.Data[1], scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }


        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_TransactionId_WithUpdatedSchema_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261-10");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = transactionIds
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Equal(scenario.TestTransactions.Count, searchResponse.TransactionsByTransactionIdQueryResponse.Data.Count);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByTransactionIdQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
           
        }

        [Fact]
		public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumberItemId_ValidData_NoResult()
		{
			var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();
            
            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });

            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
			{
				SearchRequestId = scenario.Id,
				Queries = new string[] { "Phonenumber" },
				Data = new SearchData()
				{
					PhoneNumber = "123",
					ItemId = itemIds

                }
			};
			var result = _testFixture.SearchTransactions(data, "2.0").Result;
			Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

			string responseBody = await result.Content.ReadAsStringAsync();
			Assert.NotNull(responseBody);

			var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
			Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
			Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
			Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Equal("421",searchResponse.TransactionsByPhoneNumberQueryResponse.StatusCode);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);			
		}

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumberItemId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    ItemId = itemIds

                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithNullItemId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    ItemId = null
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithEmptyItemId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    ItemId = new string[0]
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithNoItemId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber                    
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_ItemId_DateRange_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    ItemId = itemIds,
                    DateRange = new DateRange { StartDate = "2021-05-13", EndDate = "2021-05-13" }

                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithNullDateRange_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = null
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithExactDateRange_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { StartDate = "2021-05-13", EndDate = "2021-05-13" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithDateRange_DifferentDateFormat_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { StartDate = "2021/05/13", EndDate = "2021-05-13" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithDateRange_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { StartDate = "2021-05-13", EndDate = "2021-05-14" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }


        
        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumber_WithDateRange_InCorrectDate_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { StartDate = "2021-05", EndDate = "2021-05-13" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
        }

        


        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumberItemId_TransactionId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber", "TransactionId" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    ItemId = itemIds,
                    TransactionId = transactionIds

                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.NotNull(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
            Assert.Equal(transactionIds.Length,searchResponse.TransactionsByPhoneNumberQueryResponse.Data.Count);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByTransactionIdQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));
            
        }


        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumberItemId_TransactionId_FirstInvalidQuery()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber", "TransactionId" },
                Data = new SearchData()
                {
                    PhoneNumber = "test",
                    ItemId = itemIds,
                    TransactionId = transactionIds

                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.Equal("421", searchResponse.TransactionsByPhoneNumberQueryResponse.StatusCode);
            Assert.NotNull(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByTransactionIdQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));

        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_PhoneNumberItemId_TransactionId_SecondInvalidQuery()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber", "TransactionId" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    ItemId = itemIds,
                    TransactionId = new string[] { "test" }

                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse.Data);
            Assert.Equal("421", searchResponse.TransactionsByTransactionIdQueryResponse.StatusCode);
            Assert.NotNull(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Single(searchResponse.TransactionsByPhoneNumberQueryResponse.Data);
            Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPhoneNumberQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].transactionId));

        }

        [Fact]
        public async Task Search_E2ETest_Scenario_QueryByTransactionId_WithVersion1()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            SalesTransactionSearch data = new SalesTransactionSearch
            {
                SearchRequestId = scenario.Id,
                TransactionIds = transactionIds
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);            
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_CC1()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("CC1");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(9000).Wait();

            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });

            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();
            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            int storeNumber = scenario.TestTransactions[0].transactionSummary.fulfillmentStoreId;
            string firstSix = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberFirstSix;
            string lastFour = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberLastFour;




            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    ItemId = itemIds,
                    StoreId = storeNumber,
                    FirstSixCardNo = firstSix,
                    LastFourCardNo = lastFour
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.NotEmpty(searchResponse.TransactionsByPartialCardNoQueryResponse.Data);
            Assert.True(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Count > 0);
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Where(c=>c.TransactionId == scenario.ExpectedTransactions[0].TransactionId), scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].TransactionId));
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Where(c => c.TransactionId == scenario.ExpectedTransactions[1].TransactionId), scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_CC1_With_DateRange()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("CC1");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(9000).Wait();

            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });

            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();
            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            int storeNumber = scenario.TestTransactions[0].transactionSummary.fulfillmentStoreId;
            string firstSix = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberFirstSix;
            string lastFour = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberLastFour;

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    ItemId = itemIds,
                    StoreId = storeNumber,
                    FirstSixCardNo = firstSix,
                    LastFourCardNo = lastFour,
                    DateRange = new DateRange { StartDate = "2021-04-01", EndDate = "2021-04-01" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.NotEmpty(searchResponse.TransactionsByPartialCardNoQueryResponse.Data);
            Assert.True(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Count > 0);
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Where(c => c.TransactionId == scenario.ExpectedTransactions[0].TransactionId), scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].TransactionId));
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Where(c => c.TransactionId == scenario.ExpectedTransactions[1].TransactionId), scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_CC1_With_No_ItemId_DateRange()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("CC1");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(9000).Wait();

            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });

            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();
            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            int storeNumber = scenario.TestTransactions[0].transactionSummary.fulfillmentStoreId;
            string firstSix = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberFirstSix;
            string lastFour = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberLastFour;

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = storeNumber,
                    FirstSixCardNo = firstSix,
                    LastFourCardNo = lastFour,
                    DateRange = new DateRange { StartDate = "2021-04-01", EndDate = "2021-04-01" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.NotEmpty(searchResponse.TransactionsByPartialCardNoQueryResponse.Data);
            Assert.True(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Count > 0);
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data[0], scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].TransactionId));
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data[1], scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }


        [Fact]
        public async Task Search_E2ETest_Scenario_CC1_With_No_ItemId_NoDateRange()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("CC1");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(9000).Wait();

            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });

            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();
            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            int storeNumber = scenario.TestTransactions[0].transactionSummary.fulfillmentStoreId;
            string firstSix = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberFirstSix;
            string lastFour = scenario.TestTransactions[0].tenders[0].tenderEft.eftAccountNumberLastFour;

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "PartialCardNumber" },
                Data = new SearchData()
                {
                    StoreId = storeNumber,
                    FirstSixCardNo = firstSix,
                    LastFourCardNo = lastFour                    
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.NotEmpty(searchResponse.TransactionsByPartialCardNoQueryResponse.Data);
            Assert.True(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.Count > 0);
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.FirstOrDefault(c => c.TransactionId == scenario.ExpectedTransactions[0].TransactionId), scenario.ExpectedTransactions[0]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[0].TransactionId));
            //Assert.True(TestHelper.JsonCompare(searchResponse.TransactionsByPartialCardNoQueryResponse.Data.FirstOrDefault(c => c.TransactionId == scenario.ExpectedTransactions[1].TransactionId), scenario.ExpectedTransactions[1]), string.Format("Scenario {0} failed for transaction {1}", scenario.Id, scenario.TestTransactions[1].transactionId));
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_ReceiptId_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var receiptIds = scenario.TestTransactions.Select(c => (string)c.receiptDetail.receiptId).ToArray();
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "ReceiptId" },
                Data = new SearchData()
                {
                    ReceiptId = receiptIds
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByReceiptIdQueryResponse);
            Assert.True(searchResponse.TransactionsByReceiptIdQueryResponse.Data.Count > 1);
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_CustomerIdentifications_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261-10");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            int customerIdType = scenario.TestTransactions[0].customerSelfIdentifications[0].customerIdType;
            string customerId = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            int customerReasonCode = scenario.TestTransactions[0].customerSelfIdentifications[0].customerIdCaptureReasonCode;
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications= new Models.CustomerSelfIdentifications
                    {
                        CustomerId= new string[] {customerId},
                        CustomerIdType=customerIdType,
                        CustomerIdCaptureReasonCodes = new int[] { customerReasonCode }
                    }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Null(searchResponse.TransactionsByReceiptIdQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByCustomerSelfIdentificationsQuery);
            Assert.True(searchResponse.TransactionsByCustomerSelfIdentificationsQuery.Data.Count > 0);
        }

        [Fact]
        public async Task Search_E2ETest_Scenario_3261_With_FilterBy_CustomerIdentifications_DateRange_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3261-10");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();

            var transactionIds = scenario.TestTransactions.Select(c => (string)c.transactionId).ToArray();
            int customerIdType = scenario.TestTransactions[0].customerSelfIdentifications[0].customerIdType;
            string customerId = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            int customerReasonCode = scenario.TestTransactions[0].customerSelfIdentifications[0].customerIdCaptureReasonCode;
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    DateRange = new DateRange { StartDate = "2021-05-13", EndDate = "2022-05-11" },
                    CustomerSelfIdentifications = new Models.CustomerSelfIdentifications
                    {
                        CustomerId = new string[] { customerId },
                        CustomerIdType = customerIdType,
                        CustomerIdCaptureReasonCodes = new int[] {customerReasonCode}
                    }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.OK, result.StatusCode);

            string responseBody = await result.Content.ReadAsStringAsync();
            Assert.NotNull(responseBody);

            var searchResponse = JsonConvert.DeserializeObject<SalesTransactionSearchByQueriesResponse>(responseBody, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            Assert.Equal(searchResponse.SearchRequestId, data.SearchRequestId);
            Assert.Null(searchResponse.TransactionsByPartialCardNoQueryResponse);
            Assert.Null(searchResponse.TransactionsByPhoneNumberQueryResponse);
            Assert.Null(searchResponse.TransactionsByTransactionIdQueryResponse);
            Assert.Null(searchResponse.TransactionsByReceiptIdQueryResponse);
            Assert.NotNull(searchResponse.TransactionsByCustomerSelfIdentificationsQuery);
            Assert.True(searchResponse.TransactionsByCustomerSelfIdentificationsQuery.Data.Count > 0);
        }

        #endregion

        #region Search Invalid Test(s)
        [Fact]
        public async Task InValidTransaction_SearchRequest_With_EmptyBody()
        {
            var result =  await _testFixture.SearchTransactions(null);            
            Assert.Equal(System.Net.HttpStatusCode.BadRequest,result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequest_With_EmptySearchRequestId()
        {
            SalesTransactionSearch data = new SalesTransactionSearch { SearchRequestId = "", TransactionIds = new string[] { "1"} };
            var result = await  _testFixture.SearchTransactions(data);
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequest_With_EmptyTransactionIds()
        {
            SalesTransactionSearch data = new SalesTransactionSearch { SearchRequestId = "123", TransactionIds = new string[0]};
            var result = await _testFixture.SearchTransactions(data);
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequest_With_NullTransactionIds()
        {
            SalesTransactionSearch data = new SalesTransactionSearch { SearchRequestId = "123", TransactionIds = null };
            var result = await _testFixture.SearchTransactions(data);
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }


        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_EmptyBody()
        {
            SalesTransactionSearchByQueries data = null;
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_EmptySearchRequestId()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "TransactionId" }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_EmptyFilterBy()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[0] { },
                Data = new SearchData()
                {
                    TransactionId = new string[] { "TransactionId" }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_NullFilterBy()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = null,
                Data = new SearchData()
                {
                    TransactionId = new string[] { "TransactionId" }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_InvalidFilterBy()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "test"},
                Data = new SearchData()
                {
                    TransactionId = new string[] { "TransactionId" }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_FilterBy_TransactionId_EmptyData()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[0] { }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_FilterBy_TransactionId_NullData()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = null
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_FilterBy_PhoneNumberItemId_NullData()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    TransactionId = null
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_FilterBy_PhoneNumberItemId_EmptyData()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    ItemId = new string[0] { },
                    PhoneNumber = ""
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_EmptyTransactionIds()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = new string[0] { }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_NullTransactionIds()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "TransactionId" },
                Data = new SearchData()
                {
                    TransactionId = null
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_FilterBy_PhoneNumber_WithInvalidDateRange__ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { StartDate = "2021-05-13", EndDate = "2021-05-11" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
            
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_FilterBy_PhoneNumber_WithDateRange_EndDateOnly_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { EndDate = "2021-05-13" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
            
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_FilterBy_PhoneNumber_WithDateRange_StartDateOnly_ValidData()
        {
            var scenario = _testFixture.TestDataManager.GetSearchScenarioById("3239");
            await _testFixture.UpsertDataIntoCosmos(scenario.TestTransactions);

            Task.Delay(5000).Wait();
            List<dynamic> lineItems = new List<dynamic>();

            scenario.TestTransactions.ForEach(c => {
                lineItems.AddRange(c.lineItems);
            });
            var phoneNumber = scenario.TestTransactions[0].customerSelfIdentifications[0].customerId;
            var itemIds = lineItems.Select(c => (string)c.itemId).ToArray();

            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = scenario.Id,
                Queries = new string[] { "Phonenumber" },
                Data = new SearchData()
                {
                    PhoneNumber = (string)phoneNumber,
                    DateRange = new DateRange { StartDate = "2021-05-13" }
                }
            };
            var result = _testFixture.SearchTransactions(data, "2.0").Result;
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);

            
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_EmptyReceiptIds()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "ReceiptId" },
                Data = new SearchData()
                {
                    ReceiptId = new string[0] { }
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }


        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_NullReceiptIds()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "ReceiptId" },
                Data = new SearchData()
                {
                    ReceiptId = null
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_NullCustomerIds()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications = new Models.CustomerSelfIdentifications
                    {
                        CustomerId = null
                    }
                    
                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public async Task InValidTransaction_SearchRequestv2_With_EmptyCustomerIds()
        {
            SalesTransactionSearchByQueries data = new SalesTransactionSearchByQueries
            {
                SearchRequestId = "123",
                Queries = new string[] { "customerSelfIdentifications" },
                Data = new SearchData()
                {
                    CustomerSelfIdentifications = new Models.CustomerSelfIdentifications
                    {
                        CustomerId =  new string[0] { }
                    }

                }
            };
            var result = await _testFixture.SearchTransactions(data, "2.0");
            Assert.Equal(System.Net.HttpStatusCode.BadRequest, result.StatusCode);
        }
        #endregion
    }
}


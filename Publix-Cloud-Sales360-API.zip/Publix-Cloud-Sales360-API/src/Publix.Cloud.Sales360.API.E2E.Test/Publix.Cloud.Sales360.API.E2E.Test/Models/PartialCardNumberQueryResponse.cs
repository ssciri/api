﻿using Newtonsoft.Json;
using Publix.Sales360.Models;
using System.Collections.Generic;

namespace Publix.Cloud.Sales360.API.E2E.Test.Models
{
    public class PartialCardNumberQueryResponse
    {
        [JsonProperty("firstsixcardno")]
        public string FirstSixCardNo { get; set; }
        [JsonProperty("lastfourcardno")]
        public string Last4CardNo { get; set; }
        [JsonProperty("storeid")]
        public int? StoreId { get; set; }
        [JsonProperty("itemid")]
        public string[] ItemId { get; set; }
        [JsonProperty("statuscode")]
        public string StatusCode { get; set; }
        [JsonProperty("errormessage")]
        public string ErrorMessage { get; set; }
        [JsonProperty("data")]
        public List<SalesTransaction> Data { get; set; }
    }
}

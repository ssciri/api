﻿using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.API.E2E.Test.Models
{
    public class SalesTransactionInfo
    {
        public string TransactionId { get; set; }
        public string StatusCode { get; set; }
        public string ErrorMessage { get; set; }
        public SalesTransaction Data { get; set; }

    }
}

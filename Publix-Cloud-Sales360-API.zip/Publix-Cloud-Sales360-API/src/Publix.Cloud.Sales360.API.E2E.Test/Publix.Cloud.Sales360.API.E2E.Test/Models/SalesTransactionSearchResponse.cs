﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.API.E2E.Test.Models
{
    public class SalesTransactionSearchResponse
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        public IList<SalesTransactionInfo> Transactions { get; set; }
    }
}

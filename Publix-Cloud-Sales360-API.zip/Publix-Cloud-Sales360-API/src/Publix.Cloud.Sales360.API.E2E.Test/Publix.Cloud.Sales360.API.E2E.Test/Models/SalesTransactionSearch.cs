﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.API.E2E.Test.Models
{
    public class SalesTransactionSearch
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        [JsonProperty("transactionids")]
        public string[] TransactionIds { get; set; }

    }
}

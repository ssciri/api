﻿using Newtonsoft.Json;
using System;

namespace Publix.Cloud.Sales360.API.E2E.Test.Models
{
    public class SalesTransactionSearchByQueries 
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }
        [JsonProperty("queries")]
        public string[] Queries { get; set; }

        [JsonProperty("data")]
        public SearchData Data { get; set; }
    }

    public class SearchData
    {
        [JsonProperty("itemid")]
        public string[] ItemId { get; set; }
        [JsonProperty("transactionid")]
        public string[] TransactionId { get; set; }

        [JsonProperty("phonenumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("firstsixcardno")]
        public string FirstSixCardNo { get; set; }
        [JsonProperty("lastfourcardno")]
        public string LastFourCardNo { get; set; }
        [JsonProperty("storeid")]
        public int? StoreId { get; set; }
        [JsonProperty("daterange")]
        public DateRange DateRange { get; set; }
        [JsonProperty("receiptId")]
        public string[] ReceiptId { get; set; }
        [JsonProperty("customerSelfIdentifications")]
        public CustomerSelfIdentifications CustomerSelfIdentifications { get; set; }
    }

    public enum QueryName
    {
        Phonenumber_ItemId = 1,
        TransactionId = 2,
        PartialCardNumber = 3,
        ReceiptId = 4
    }

    public class DateRange
    {
        [JsonProperty("startdate")]
        public string StartDate { get; set; }
        [JsonProperty("enddate")]
        public string EndDate { get; set; }

    }

    public class CustomerSelfIdentifications
    {
        public string[] CustomerId { get; set; }
        public Int32? CustomerIdType { get; set; }
        public int[] CustomerIdCaptureReasonCodes { get; set; }
    }
}

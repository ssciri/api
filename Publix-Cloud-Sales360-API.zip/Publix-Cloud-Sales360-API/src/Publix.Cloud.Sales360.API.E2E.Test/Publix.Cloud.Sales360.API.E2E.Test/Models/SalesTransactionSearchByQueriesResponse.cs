﻿using Newtonsoft.Json;
using Publix.Sales360.Models;
using System.Collections.Generic;


namespace Publix.Cloud.Sales360.API.E2E.Test.Models
{
    public class SalesTransactionSearchByQueriesResponse
    {
        [JsonProperty("searchrequestid")]
        public string SearchRequestId { get; set; }

        [JsonProperty("phonenumber_itemid_query_response")]
        public PhoneNumberQueryResponse TransactionsByPhoneNumberQueryResponse { get; set; }

        [JsonProperty("transactionid_query_response")]
        public SalesTransactionsQueryResponse TransactionsByTransactionIdQueryResponse { get; set; }

        [JsonProperty("partialcardnumber_query_response")]
        public PartialCardNumberQueryResponse TransactionsByPartialCardNoQueryResponse { get; set; }

        [JsonProperty("receiptid_query_response")]
        public SalesTransactionsQueryResponse TransactionsByReceiptIdQueryResponse { get; set; }

        [JsonProperty("customerSelfIdentifications_query_response")]
        public SalesTransactionsQueryResponse TransactionsByCustomerSelfIdentificationsQuery { get; set; }
    }
}

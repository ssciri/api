﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.API.E2E.Test.Common.Cosmos
{
    public interface ICosmosAPI
    {
        Task UpsertAsync<T>(string containerId, T salesTransactionJson);
        Task DeleteAsync<T>(string containerId, T salesTransactionJson, string id);        
    }
}

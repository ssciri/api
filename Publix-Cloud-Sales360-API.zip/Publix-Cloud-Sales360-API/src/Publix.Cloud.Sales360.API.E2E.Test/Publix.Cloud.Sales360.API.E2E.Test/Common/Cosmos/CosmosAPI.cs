﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Publix.Cloud.Sales360.API.E2E.Test.Common.Cosmos
{
	public class CosmosAPI : ICosmosAPI
	{
		private readonly CosmosClient _cosmosClient;
		private readonly string _databaseName;
		
		public CosmosAPI(IConfiguration config)
		{
			var connectionString = config["SalesCosmosConnectionString"];
			_databaseName = config["Cosmos_SalesTransaction_Database_ID"];

			int maxRetryAttempts = 3; 
			int maxRetryWaitTime = 2; 

			_cosmosClient = new CosmosClient(connectionString,
				new CosmosClientOptions
				{					
					ConnectionMode = ConnectionMode.Gateway,
					WebProxy = new System.Net.WebProxy("http://webproxy1.publix.inet:9090"),
					MaxRetryAttemptsOnRateLimitedRequests = maxRetryAttempts,
					MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(maxRetryWaitTime)					
				}) ;
		}

		public async Task UpsertAsync<T>(string containerName, T salesTransactionJson)
		{
			var container = _cosmosClient.GetContainer(_databaseName, containerName);
			await container.UpsertItemAsync(salesTransactionJson);
		}

		public async Task DeleteAsync<T>(string containerName, T salesTransactionJson, string id)
		{
			var container = _cosmosClient.GetContainer(_databaseName, containerName);
			await container.DeleteItemAsync<T>(id, new PartitionKey(id));
		}

		public async Task<IList<T>> GetItemsAsync<T>(string containerName, string query, IDictionary<string, object> parameters = null)
		{
			List<T> results = new List<T>();

			var queryDefinition = BuildQueryDefinition(query, parameters);
			var container = _cosmosClient.GetContainer(_databaseName, containerName);

			using (FeedIterator<T> resultSet = container.GetItemQueryIterator<T>(
				queryDefinition: queryDefinition))
			{
				while (resultSet.HasMoreResults)
				{
					FeedResponse<T> response = await resultSet.ReadNextAsync();
					results.AddRange(response);
				}
			}
			return results;
		}


		public async Task CreateContainerAsync(string containerName, string partitionKey)
		{
			var database = _cosmosClient.GetDatabase(_databaseName);
			await database.CreateContainerIfNotExistsAsync(containerName, partitionKey);
		}

		public async Task DeleteContainerAsync(string containerName)
		{
			await _cosmosClient.GetContainer(_databaseName, containerName).DeleteContainerAsync();
		}

		private static QueryDefinition BuildQueryDefinition(string query, IDictionary<string, object> parameters)
		{
			var queryDefinition = new QueryDefinition(query);
			if (parameters != null)
			{
				foreach (KeyValuePair<string, object> entry in parameters)
				{
					queryDefinition.WithParameter(entry.Key, entry.Value);
				}
			}
			return queryDefinition;
		}
	}
}

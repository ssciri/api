﻿using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Publix.Cloud.Sales360.API.E2E.Test.Common.Cosmos;
using Publix.Cloud.Sales360.API.E2E.Test.Models;
using Publix.Cloud.Sales360.API.E2E.Test.Utility;
using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;
namespace Publix.Cloud.Sales360.API.E2E.Test.Common
{
    public class AzureTestFixture : IAsyncLifetime
    {
        static IConfiguration config = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", true, true)
          .Build();

        private readonly IMessageSink _sink;
        private string _containerName;
        private HttpClient _client;
        private string _searchEndPoint;
        private HttpClientHandler _handler;

        public async Task UpsertDataIntoCosmos(List<dynamic> data)
		{
			foreach (var transction in data)
			{
                await _cosmosAPI.UpsertAsync<dynamic>(_containerName, transction);
			}
		}

		private ICosmosAPI _cosmosAPI;
        
        public TestDataManager TestDataManager { get; set; }

        public AzureTestFixture(IMessageSink sink)
        {
            _sink = sink;
            _cosmosAPI = new CosmosAPI(config);            

            _containerName = config["Cosmos_SalesTransaction_Container_ID"];
            TestDataManager = new TestDataManager();
            _searchEndPoint = config["Search_EndPoint"];
        }

		private async Task<AuthenticationHeaderValue> GetAuthuorizationHeader()
		{
            var authority = String.Format(CultureInfo.InvariantCulture, config["Instance"], config["TenantId"]);
            var app = ConfidentialClientApplicationBuilder.Create(config["ClientId"])
                    .WithClientSecret(config["ClientSecret"])
                    .WithAuthority(new Uri(authority))
                    .Build();
            string[] scopes = new string[] { config["TodoListScope"]};
            AuthenticationResult result = null;
            result = await app.AcquireTokenForClient(scopes)
                    .ExecuteAsync();
            return new AuthenticationHeaderValue("Bearer", result.AccessToken);
        }

        public async Task InitializeAsync()
        {
            var proxy = new WebProxy
            {
                Address = new Uri("http://webproxy1.publix.inet:9090/"),
                BypassProxyOnLocal = true,
                UseDefaultCredentials = true,
            };

            _handler = new HttpClientHandler();
            _handler.UseProxy = true;
            _handler.Proxy = proxy;

            _client = new HttpClient(_handler);
            _client.BaseAddress = new Uri(config["Sales360Api_Base_Url"]);
            var defaultRequestHeaders = _client.DefaultRequestHeaders;
            if (defaultRequestHeaders.Accept == null || !defaultRequestHeaders.Accept.Any(m => m.MediaType == "application/json"))
            {
                _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            }
            _client.DefaultRequestHeaders.Authorization = await GetAuthuorizationHeader();
            //Console.WriteLine(accessToken);            
        }

        public Task DisposeAsync()
        {
            _client.Dispose();
            _handler.Dispose();
            return Task.CompletedTask;
        }

        public async Task<HttpResponseMessage> SearchTransactions(SalesTransactionSearch data)
		{
            var company = JsonConvert.SerializeObject(data);
            var requestContent = new StringContent(company, Encoding.UTF8, "application/json");
            return await _client.PostAsync(_searchEndPoint, requestContent);
		}

        public async Task<HttpResponseMessage> SearchTransactions(SalesTransactionSearchByQueries data, string versionInfo)
        {
            var company = JsonConvert.SerializeObject(data);
            var content = "application/json";
            var requestContent = new StringContent(company, Encoding.UTF8, content);
            requestContent.Headers.ContentType.Parameters.Add(new NameValueHeaderValue("version", versionInfo));
            return await _client.PostAsync(_searchEndPoint, requestContent);
        }

        public async Task<HttpResponseMessage> SearchTransactions(SalesTransactionSearch data, string versionInfo)
        {
            var company = JsonConvert.SerializeObject(data);
            var content = "application/json";
            var requestContent = new StringContent(company, Encoding.UTF8, content);
            requestContent.Headers.ContentType.Parameters.Add(new NameValueHeaderValue("version", versionInfo));
            return await _client.PostAsync(_searchEndPoint, requestContent);
        }
    }
}

﻿using Publix.Sales360.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.API.E2E.Test.Utility
{
    public class TestScenarios
    {
        public string ScenarioType { get; set; }
        public List<Scenario> Scenarios { get; set; }
    }

    public class Scenario
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<dynamic> TestTransactions { get; set; }
        public List<SalesTransaction> ExpectedTransactions { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Publix.Cloud.Sales360.API.E2E.Test.Utility
{
    public class TestHelper
    {
        public static bool JsonCompare(object obj, object another)
        {
            if (ReferenceEquals(obj, another)) return true;
            if ((obj == null) || (another == null)) return false;
            if (obj.GetType() != another.GetType()) return false;

            var objJson = JsonConvert.SerializeObject(obj);
            var anotherJson = JsonConvert.SerializeObject(another);

            return objJson == anotherJson;
        }
    }
}

﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Publix.Cloud.Sales360.API.E2E.Test.Utility
{
    public class TestDataManager
    {
        private TestScenarios _scenarios;

        public Scenario GetSearchScenarioById(string id)
        {
            if (_scenarios == null)
            {
                _scenarios = LoadTestSalesTransactions("SearchTestData.json");
            }
            return _scenarios.Scenarios.FirstOrDefault(c => c.Id == id);
        }


        public TestScenarios LoadTestSalesTransactions(string fileName)
        {
            var localPath = "./../../../Testdata";
            var localFilePath = Path.Combine(localPath, fileName);
            var data = File.ReadAllText(localFilePath);
            var scenarios = JsonConvert.DeserializeObject<TestScenarios>(data, new JsonSerializerSettings() { DateParseHandling = DateParseHandling.None });
            string dynamicPostfix = DateTime.Now.ToString("MMddyyHHmm");
            //set unique Id's
            scenarios.Scenarios.
                ForEach(c => {
                    c.TestTransactions.ForEach(d => {
                        d.id = d.id + "_" + dynamicPostfix;
                        d.transactionId = d.transactionId + "_" + dynamicPostfix;
                        d.receiptDetail.receiptId = d.receiptDetail.receiptId + "_" + dynamicPostfix;


                            if (d.customerSelfIdentifications != null && ((JArray)d.customerSelfIdentifications).Count > 0)
						    {
                                d.customerSelfIdentifications[0].customerId = d.customerSelfIdentifications[0].customerId + "_" + dynamicPostfix;
                            }
                        });
                    c.ExpectedTransactions.ForEach(d => {
                        d.Id = d.TransactionId + "_" + dynamicPostfix;
                        d.TransactionId = d.TransactionId + "_" + dynamicPostfix;
                        if(d.ReceiptDetail != null)
                            d.ReceiptDetail.ReceiptId = d.ReceiptDetail.ReceiptId + "_" + dynamicPostfix;
                        if (d.CustomerSelfIdentifications != null && d.CustomerSelfIdentifications.Count() > 0)
                        {
                            d.CustomerSelfIdentifications[0].CustomerId = d.CustomerSelfIdentifications[0].CustomerId + "_" + dynamicPostfix;
                        }
                    });                    
                    
                    
                });

            return scenarios;
        }
    }
}
